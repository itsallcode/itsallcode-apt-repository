# Example requirements

## C
`req~c-source~1`
Needs: src

## C uppercase
`req~Cuppercase-source~1`
Needs: src

## Java
`req~java-source~1`
Needs: src

## C++
`req~c++-source~1`
Needs: src

## Cpp
`req~cpp-source~1`
Needs: src

## Sql
`req~sql-source~1`
Needs: src

## Visual Basic
`req~vb-source~1`
Needs: src

## JSX
`req~jsx-source~1`
Needs: src

## TSX
`req~tsx-source~1`
Needs: src
