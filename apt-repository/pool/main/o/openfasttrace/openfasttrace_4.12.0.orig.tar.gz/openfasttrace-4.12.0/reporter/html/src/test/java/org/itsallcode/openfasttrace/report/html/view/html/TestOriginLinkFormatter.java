package org.itsallcode.openfasttrace.report.html.view.html;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.itsallcode.openfasttrace.report.html.view.html.OriginLinkFormatter.formatAsBlock;
import static org.itsallcode.openfasttrace.report.html.view.html.OriginLinkFormatter.formatAsSpan;

import org.itsallcode.openfasttrace.api.core.Location;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.*;

class TestOriginLinkFormatter
{
    @Test
    void testNullOrigin()
    {
        assertThat(formatAsSpan(null), equalTo(""));
    }

    @Test
    void testEmptyOrigin()
    {
        assertThat(formatAsSpan(Location.create("", 1)), equalTo(""));
    }

    @Test
    void testFormatMinimalHttpLink()
    {
        assertPathAndLineRenderedToSpan("http://example.org", 1,
                "<a href=\"http://example.org\">http://example.org</a>:1");
    }

    private void assertPathAndLineRenderedToSpan(final String path, final int line,
            final String expected)
    {
        assertThat(formatAsSpan(Location.create(path, line)),
                equalTo("<span class=\"origin\">" + expected + "</span>"));
    }

    @Test
    void testFormatMinimalHttpLinkAsBlock()
    {
        assertPathAndLineRenderedToBlock("http://example.org", 1,
                "<a href=\"http://example.org\">http://example.org</a>:1");
    }

    @Test
    void testFormatHttpLinkWithSpecialCharacters()
    {
        assertPathAndLineRenderedToBlock("http://äöü.org", 1,
                "<a href=\"http://äöü.org\">http://äöü.org</a>:1");
    }

    private void assertPathAndLineRenderedToBlock(final String path, final int line,
            final String expected)
    {
        assertThat(formatAsBlock(Location.create(path, line)),
                equalTo("<p class=\"origin\">" + expected + "</p>"));
    }

    @Test
    void testLongerHttpLink()
    {
        assertPathAndLineRenderedToSpan("http://example.org/foo/bar%20baz?zoo", 1,
                "<a href=\"http://example.org/foo/bar%20baz?zoo\">http://example.org/foo/bar%20baz?zoo</a>:1");
    }

    @Test
    @DisabledOnOs(OS.WINDOWS)
    void testFormatRegularAbsoluteUnixPath()
    {
        assertPathAndLineRenderedToSpan("/foo/bar/baz", 1111,
                "<a href=\"file:///foo/bar/baz\">/foo/bar/baz</a>:1111");
    }

    @Test
    @EnabledOnOs(OS.WINDOWS)
    void testFormatRegularAbsoluteWindowsPath()
    {
        assertPathAndLineRenderedToSpan("C:\\foo\\bar\\baz", 1111,
                "<a href=\"file:///C:/foo/bar/baz\">C:\\foo\\bar\\baz</a>:1111");
    }

    @Test
    @EnabledOnOs(OS.LINUX)
    void testFormatAbsoluteUnixPathWithSpecialCharactersLinux()
    {
        assertPathAndLineRenderedToSpan("/fo o/bär/baz", 12345678,
                "<a href=\"file:///fo%20o/b%C3%A4r/baz\">/fo o/bär/baz</a>:12345678");
    }

    @Test
    @EnabledOnOs(OS.MAC)
    void testFormatAbsoluteUnixPathWithSpecialCharactersMacOs()
    {
        // macOS filesystem providers may expose this path in NFC or NFD form;
        // Path.toUri() preserves that form, so JDK and GraalVM builds can differ.
        final String actual = formatAsSpan(Location.create("/fo o/bär/baz", 12345678));
        assertThat(actual, anyOf(
                equalTo("<span class=\"origin\"><a href=\"file:///fo%20o/b%C3%A4r/baz\">/fo o/bär/baz</a>:12345678</span>"),
                equalTo("<span class=\"origin\"><a href=\"file:///fo%20o/ba%CC%88r/baz\">/fo o/bär/baz</a>:12345678</span>")));
    }

    @Test
    void testFormatRelativeUnixPath()
    {
        assertPathAndLineRenderedToSpan("foo/bar/baz", 2, "foo/bar/baz:2");
    }

    @Test
    void testFormatRelativeUnixPathWithSpecialCharacters()
    {
        assertPathAndLineRenderedToSpan("foo/bär/baz", 2, "foo/bär/baz:2");
    }

    @Test
    void testIllegalUri()
    {
        assertPathAndLineRenderedToSpan("http://example.org/a b", 5, "http://example.org/a b:5");
    }
}
