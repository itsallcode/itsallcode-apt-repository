package org.itsallcode.openfasttrace.api.core;

import java.util.Comparator;
import java.util.Objects;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Specification item ID
 * <p>
 * Consists of an artifact type (e.g. "test"), a name and a revision number.
 * </p>
 */
// [impl->dsn~specification-item-id~1]
public final class SpecificationItemId implements Comparable<SpecificationItemId>
{
    private static final Logger LOG = Logger.getLogger(SpecificationItemId.class.getName());

    /**
     * Value for an unknown artifact type in case the type could not be
     * determined for a legacy item ID.
     */
    public static final String UNKNOWN_ARTIFACT_TYPE = "unknown";
    /** Regexp pattern for revision number. */
    public static final String ITEM_REVISION_PATTERN = "(\\d+)";
    /** Regexp pattern for item names. */
    public static final String ITEM_NAME_PATTERN = "(?U)(\\p{Alpha}[\\w-]*(?:\\.[\\w-]+)*+)";
    private static final String LEGACY_ID_NAME = "(\\p{Alpha}+)(?:~\\p{Alpha}+)?:"
            + ITEM_NAME_PATTERN;
    /** Separator between the artifact type and name in an item ID. */
    public static final String ARTIFACT_TYPE_SEPARATOR = "~";
    /**
     * Separator between name and revision in an item ID.
     * 
     * @deprecated with 4.12.0 we widened the accepted separators to include '#'.
     *             Use {@link #REVISION_SEPARATOR_PATTERN} for detection or {@link #DEFAULT_REVISION_SEPARATOR} for
     *             output instead.
     */
    @Deprecated(forRemoval = true, since = "4.12.0")
    public static final String REVISION_SEPARATOR = "~";
    /** Since 4.12.0 OFT supports "~" and "#" revision separators when reading. The default for writing remains "~". */
    public static final String DEFAULT_REVISION_SEPARATOR = "~";
    /** Regexp pattern for accepted separators between name and revision. */
    public static final String REVISION_SEPARATOR_PATTERN = "[~#]";
    static final int REVISION_WILDCARD = Integer.MIN_VALUE;
    // [impl->dsn~md.specification-item-id-format~4]
    private static final String ID = "(\\p{Alpha}+)" //
            + ARTIFACT_TYPE_SEPARATOR //
            + ITEM_NAME_PATTERN //
            + REVISION_SEPARATOR_PATTERN //
            + ITEM_REVISION_PATTERN;
    private static final String LEGACY_ID = LEGACY_ID_NAME + ", *v" //
            + ITEM_REVISION_PATTERN;
    private static final int ARTIFACT_TYPE_MATCHING_GROUP = 1;
    private static final int NAME_MATCHING_GROUP = 2;
    private static final int REVISION_MATCHING_GROUP = 3;
    /** Regexp pattern for item IDs: {@code <type>~<name>~<revision>} */
    public static final Pattern ID_PATTERN = Pattern.compile(ID);
    private static final Pattern LEGACY_NAME_PATTERN = Pattern.compile(LEGACY_ID_NAME);
    /** Regexp pattern for legacy item IDs: {@code <name>, v<revision>}. */
    public static final Pattern LEGACY_ID_PATTERN = Pattern.compile(LEGACY_ID);

    private final String name;
    private final int revision;
    private final String artifactType;

    private SpecificationItemId(final String name, final String artifactType, final int revision)
    {
        this.name = name;
        this.artifactType = artifactType;
        this.revision = revision;
    }

    /**
     * Get the name part of the ID
     *
     * @return the name part of the ID
     */
    public String getName()
    {
        return this.name;
    }

    /**
     * Get the revision number
     *
     * @return the revision number
     */
    public int getRevision()
    {
        return this.revision;
    }

    /**
     * Get the artifact type
     *
     * @return the artifact type
     */
    public String getArtifactType()
    {
        return this.artifactType;
    }

    @Override
    public boolean equals(final Object o)
    {
        if (!(o instanceof final SpecificationItemId that))
        {
            return false;
        }
        return revision == that.revision && Objects.equals(name, that.name)
                && Objects.equals(artifactType, that.artifactType);
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(name, revision, artifactType);
    }

    @Override
    public String toString()
    {
        return this.artifactType + ARTIFACT_TYPE_SEPARATOR + this.name + DEFAULT_REVISION_SEPARATOR + this.revision;
    }

    /**
     * Get this item with a wildcard as revision.
     *
     * @return a copy of this ID with a wildcard as revision.
     */
    public SpecificationItemId toRevisionWildcard()
    {
        return new Builder().artifactType(this.artifactType).name(this.name).revisionWildcard()
                .build();
    }

    /**
     * Parse a string for a specification item ID
     *
     * @param idText
     *            the string to be parsed
     * @return the specification item ID
     */
    public static SpecificationItemId parseId(final String idText)
    {
        return new Builder(idText).build();
    }

    /**
     * Create a specification item ID from an already-matched {@link #ID_PATTERN}
     * matcher.
     * <p>
     * The matcher must use {@link #ID_PATTERN} and must already have a current
     * match from {@link Matcher#matches()} or {@link Matcher#find()}. This does
     * not accept {@link #LEGACY_ID_PATTERN}.
     * </p>
     *
     * @param matcher
     *            an already-matched matcher whose pattern is {@link #ID_PATTERN}
     * @return the specification item ID
     * @throws IllegalArgumentException
     *             if the matcher's pattern is not {@link #ID_PATTERN}, or if the
     *             revision cannot be parsed
     * @throws IllegalStateException
     *             if the matcher has no current match
     */
    public static SpecificationItemId fromIdPatternMatcher(final Matcher matcher)
    {
        if (matcher.pattern() != ID_PATTERN)
        {
            throw new IllegalArgumentException(
                    "Matcher pattern must be SpecificationItemId.ID_PATTERN, but was '"
                            + matcher.pattern() + "'");
        }
        final Builder builder = new Builder();
        builder.setIdPartsFromMatches(matcher);
        return builder.build();
    }

    /**
     * Create a specification item ID
     *
     * @param artifactType
     *            the artifact type
     * @param name
     *            the specification item name
     * @param revision
     *            the revision
     * @return the specification item ID
     */
    public static SpecificationItemId createId(final String artifactType, final String name, final int revision)
    {
        return new SpecificationItemId.Builder().artifactType(artifactType).name(name)
                .revision(revision).build();
    }

    /**
     * Create a specification item ID with a revision wildcard
     *
     * @param artifactType
     *            the artifact type
     * @param name
     *            the specification item name
     * @return the specification item ID
     */
    public static SpecificationItemId createId(final String artifactType, final String name)
    {
        return new SpecificationItemId.Builder().artifactType(artifactType).name(name)
                .revisionWildcard().build();
    }

    /**
     * Create a new {@link Builder}
     */
    public static class Builder
    {
        // [impl->dsn~md.specification-item-id-format~4]
        private final String id;
        private String artifactType;
        private String name;
        private int revision;

        /**
         * Create a new {@link Builder} and initialize it with the string
         * representation of a specification item ID
         *
         * @param id
         *            the string representation of a specification item ID
         */
        public Builder(final String id)
        {
            this.id = id;
        }

        /**
         * Create a {@link Builder} for a {@link SpecificationItemId}
         */
        public Builder()
        {
            this(null);
        }

        /**
         * Set the artifact type
         *
         * @param artifactType
         *            the artifact type
         * @return this builder
         */
        public Builder artifactType(final String artifactType)
        {
            this.artifactType = artifactType;
            return this;
        }

        /**
         * Set the ID name part
         *
         * @param name
         *            the name part of the ID
         * @return this builder
         */
        public Builder name(final String name)
        {
            this.name = name;
            return this;
        }

        /**
         * Set the revision number of the ID
         *
         * @param revision
         *            the revision number
         *
         * @return this builder
         */
        public Builder revision(final int revision)
        {
            this.revision = revision;
            return this;
        }

        /**
         * Turn the ID into an ID with a revision wildcard.
         *
         * @return this builder
         */
        public Builder revisionWildcard()
        {
            this.revision = SpecificationItemId.REVISION_WILDCARD;
            return this;
        }

        /**
         * Build a specification item ID
         *
         * @return the ID
         */
        public SpecificationItemId build()
        {
            if (this.id == null)
            {
                validateFields();
                cleanUpLegacyIds();
            }
            else
            {
                parseId();
            }

            return new SpecificationItemId(this.name, this.artifactType, this.revision);
        }

        private void validateFields()
        {
            if (this.name == null)
            {
                throw new IllegalStateException("Name is missing in ID '" + id + "'");
            }
        }

        private void cleanUpLegacyIds()
        {
            if (this.artifactType == null || this.artifactType.isEmpty())
            {
                inferArtifactType();
            }

            removeSuperfluousArtifactPrefix();
        }

        private void inferArtifactType()
        {
            final Matcher matcher = LEGACY_NAME_PATTERN.matcher(this.name);
            if (matcher.matches())
            {
                this.artifactType = matcher.group(ARTIFACT_TYPE_MATCHING_GROUP);
            }
            else
            {
                LOG.warning(() -> "Name '" + this.name + "' does not match legacy name pattern '"
                        + LEGACY_NAME_PATTERN + "': using artifact type '" + UNKNOWN_ARTIFACT_TYPE
                        + "'.");
                this.artifactType = UNKNOWN_ARTIFACT_TYPE;
            }
        }

        private void removeSuperfluousArtifactPrefix()
        {
            final Matcher matcher = LEGACY_NAME_PATTERN.matcher(this.name);
            if (matcher.matches())
            {
                this.name = matcher.group(NAME_MATCHING_GROUP);
            }
        }

        private void parseId()
        {
            final Matcher matcher = ID_PATTERN.matcher(this.id);
            if (matcher.matches())
            {
                setIdPartsFromMatches(matcher);
            }
            else
            {
                final Matcher legacyMatcher = LEGACY_ID_PATTERN.matcher(this.id);
                if (legacyMatcher.matches())
                {
                    setIdPartsFromMatches(legacyMatcher);
                }
                else
                {
                    throw new IllegalArgumentException("Invalid specification item ID format: \"" + this.id
                            + "\". Format must be <artifact-type>~<requirement-name-or-number>(~|#)<revision>.");
                }
            }
        }

        private void setIdPartsFromMatches(final Matcher matcher)
        {
            this.artifactType = matcher.group(ARTIFACT_TYPE_MATCHING_GROUP);
            this.name = matcher.group(NAME_MATCHING_GROUP);
            parseRevision(matcher.group(REVISION_MATCHING_GROUP), matcher.group());
        }

        private void parseRevision(final String text, final String idText)
        {
            try
            {
                this.revision = Integer.parseInt(text);
            }
            catch (final NumberFormatException exception)
            {
                throw new IllegalArgumentException(
                        "Error parsing version number from specification item ID: \"" + idText
                                + "\"",
                        exception);
            }
        }
    }

    @Override
    public int compareTo(final SpecificationItemId other)
    {
        return Comparator.comparing(SpecificationItemId::getArtifactType)
                .thenComparing(SpecificationItemId::getName)
                .thenComparingInt(SpecificationItemId::getRevision)
                .compare(this, other);
    }
}
