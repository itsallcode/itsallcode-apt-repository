package org.itsallcode.openfasttrace.api.importer;

import java.util.*;

import org.itsallcode.openfasttrace.api.FilterSettings;
import org.itsallcode.openfasttrace.api.core.*;

/**
 * The {@link SpecificationListBuilder} consumes import events and generates a
 * map of specification items from them. The key to the map is the specification
 * item ID.
 */
public final class SpecificationListBuilder implements ImportEventListener
{
    private final FilterSettings filterSettings;
    private final List<SpecificationItem> items = new LinkedList<>();
    private SpecificationItem.Builder itemBuilder;
    private LocatedSpecificationItemId id;
    private StringBuilder description = new StringBuilder();
    private StringBuilder rationale = new StringBuilder();
    private StringBuilder comment = new StringBuilder();
    private Location location;

    private SpecificationListBuilder(final FilterSettings filterSettings)
    {
        this.filterSettings = filterSettings;
    }

    /**
     * Creates a new {@link SpecificationListBuilder}.
     *
     * @return a new {@link SpecificationListBuilder}.
     */
    public static SpecificationListBuilder create()
    {
        return new SpecificationListBuilder(FilterSettings.builder().build());
    }

    /**
     * Creates a new {@link SpecificationListBuilder} with the given
     * {@link FilterSettings}.
     *
     * @param filterSettings
     *            the filter settings for the new builder.
     * @return a new {@link SpecificationListBuilder}.
     */
    public static SpecificationListBuilder createWithFilter(final FilterSettings filterSettings)
    {
        return new SpecificationListBuilder(filterSettings);
    }

    @Override
    public void beginSpecificationItem()
    {
        this.itemBuilder = SpecificationItem.builder();
    }

    private void resetState()
    {
        this.itemBuilder = null;
        this.description = new StringBuilder();
        this.rationale = new StringBuilder();
        this.comment = new StringBuilder();
        this.location = null;
        this.id = null;
    }

    @Override
    @SuppressWarnings("removal") // Need to implement method from interface for backward compatibility
    public void setId(final SpecificationItemId id)
    {
        this.setId(LocatedSpecificationItemId.builder().id(id).build());
    }

    @Override
    public void setId(final LocatedSpecificationItemId id)
    {
        // [impl->dsn~located-specification-item-id-storage~1]
        this.id = id;
    }

    @Override
    public void setStatus(final ItemStatus status)
    {
        this.itemBuilder.status(status);
    }

    @Override
    @SuppressWarnings("removal") // Need to implement method from interface for backward compatibility
    public void addCoveredId(final SpecificationItemId id)
    {
        this.addCoveredId(LocatedSpecificationItemId.builder().id(id).build());
    }

    @Override
    public void addCoveredId(final LocatedSpecificationItemId id)
    {
        // [impl->dsn~filtering-by-artifact-types-during-import~1]
        // [impl->dsn~located-specification-item-id-storage~1]
        if (isAcceptedArtifactType(id.getId().getArtifactType()))
        {
            this.itemBuilder.addCoveredId(id);
        }
    }

    @Override
    public void appendDescription(final String fragment)
    {
        this.description.append(fragment);
    }

    @Override
    public void appendRationale(final String fragment)
    {
        this.rationale.append(fragment);
    }

    @Override
    public void appendComment(final String fragment)
    {
        this.comment.append(fragment);
    }

    @Override
    @SuppressWarnings("removal") // Need to implement method from interface for backward compatibility
    public void addDependsOnId(final SpecificationItemId id)
    {
        this.addDependsOnId(LocatedSpecificationItemId.builder().id(id).build());
    }

    @Override
    public void addDependsOnId(final LocatedSpecificationItemId id)
    {
        // [impl->dsn~filtering-by-artifact-types-during-import~1]
        // [impl->dsn~located-specification-item-id-storage~1]
        if (isAcceptedArtifactType(id.getId().getArtifactType()))
        {
            this.itemBuilder.addDependOnId(id);
        }
    }

    @Override
    public void addNeededArtifactType(final String artifactType)
    {
        // [impl->dsn~filtering-by-artifact-types-during-import~1]
        if (isAcceptedArtifactType(artifactType))
        {
            this.itemBuilder.addNeedsArtifactType(artifactType);
        }
    }

    @Override
    public void addTag(final String tag)
    {
        this.itemBuilder.addTag(tag);
    }

    /**
     * Build the list of specification items
     *
     * @return the list of specification items collected up to this point
     */
    public List<SpecificationItem> build()
    {
        this.endSpecificationItem();
        return Collections.unmodifiableList(this.items);
    }

    /**
     * Get the total number of items.
     *
     * @return the total number of items.
     */
    public int getItemCount()
    {
        return this.items.size();
    }

    @Override
    public void setTitle(final String title)
    {
        this.itemBuilder.title(title);
    }

    @Override
    public void setLocation(final String path, final int line)
    {
        this.setLocation(Location.create(path, line));
    }

    @Override
    public void setLocation(final Location location)
    {
        this.location = location;
    }

    @Override
    public void endSpecificationItem()
    {
        if (this.itemBuilder != null)
        {
            final SpecificationItem item = createNewSpecificationItem();
            // [impl->dsn~filtering-by-artifact-types-during-import~1]
            addSpecificationItem(item);
        }
        resetState();
    }

    @Override
    public void addSpecificationItem(final SpecificationItem item)
    {
        if (isAccepted(item))
        {
            addNewItemToList(item);
        }
    }

    // [impl->dsn~cleaning-imported-multi-line-text-elements~1]
    private SpecificationItem createNewSpecificationItem()
    {
        return this.itemBuilder //
                .id(this.id) //
                .description(this.description.toString().trim()) //
                .rationale(this.rationale.toString().trim()) //
                .comment(this.comment.toString().trim()) //
                .location(this.location) //
                .build();
    }

    private boolean isAccepted(final SpecificationItem item)
    {
        return isAcceptedArtifactType(item.getArtifactType())
                && isAcceptedStatus(item.getStatus())
                && matchesTagsCriteria(item.getTags());
    }

    // [impl->dsn~filtering-by-item-status-during-import~1]
    private boolean isAcceptedStatus(final ItemStatus status)
    {
        return !this.filterSettings.isStatusCriteriaSet()
                || this.filterSettings.getWantedStatuses().contains(status);
    }

    // [impl->dsn~filtering-by-tags-during-import~1]
    // [impl->dsn~filtering-by-tags-or-no-tags-during-import~1]
    private boolean matchesTagsCriteria(final List<String> tags)
    {
        return !this.filterSettings.isTagCriteriaSet()
                || (this.filterSettings.withoutTags() && tags.isEmpty())
                || !Collections.disjoint(this.filterSettings.getTags(), tags);
    }

    private boolean isAcceptedArtifactType(final String artifactType)
    {
        return !this.filterSettings.isArtifactTypeCriteriaSet()
                || this.filterSettings.getArtifactTypes().contains(artifactType);
    }

    private void addNewItemToList(final SpecificationItem item)
    {
        this.items.add(item);
    }

    @Override
    public void setForwards(final boolean forwards)
    {
        this.itemBuilder.forwards(forwards);
    }
}
