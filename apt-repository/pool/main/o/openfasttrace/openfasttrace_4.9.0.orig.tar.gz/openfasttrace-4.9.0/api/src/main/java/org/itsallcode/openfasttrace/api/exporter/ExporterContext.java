package org.itsallcode.openfasttrace.api.exporter;

import org.itsallcode.openfasttrace.api.core.serviceloader.Initializable;

/**
 * Context for {@link ExporterFactory} implementations. Currently only used to
 * satisfy {@link Initializable} interface.
 */
// Class is empty by intention
@SuppressWarnings("squid:S2094")
public class ExporterContext
{
    /**
     * Creates a new {@link ExporterContext} instance.
     */
    public ExporterContext() {
        // Empty by intention
    }
}
