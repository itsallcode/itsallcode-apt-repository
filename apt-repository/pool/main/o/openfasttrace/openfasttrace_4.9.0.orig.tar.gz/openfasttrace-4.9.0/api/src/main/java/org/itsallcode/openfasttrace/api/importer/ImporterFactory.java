package org.itsallcode.openfasttrace.api.importer;

import org.itsallcode.openfasttrace.api.core.serviceloader.Initializable;
import org.itsallcode.openfasttrace.api.importer.input.InputFile;

/**
 * Interface for factories producing {@link Importer}s.
 */
public interface ImporterFactory extends Initializable<ImporterContext>
{
    /**
     * Get the priority of this {@link ImporterFactory}.
     * <p>
     * The priority is used to determine the order in which importer factories
     * are tried when importing a file. Lower priority values indicate higher
     * precedence.
     * </p>
     * 
     * @return priority of this importer factory
     */
    int getPriority();

    /**
     * Returns {@code true} if this {@link ImporterFactory} supports
     * importing the given file based on its file extension.
     *
     * @param file
     *            the file to check.
     * @return {@code true} if the given file is supported for importing.
     */
    boolean supportsFile(final InputFile file);

    /**
     * Create an importer that is able to read the given file.
     *
     * @param file
     *            the file from which specification items are imported
     * @param listener
     *            the listener to be informed about detected specification item
     *            fragments
     * @return an importer instance
     */
    Importer createImporter(final InputFile file, final ImportEventListener listener);

    /**
     * Get the {@link ImporterContext}.
     * 
     * @return the {@link ImporterContext}.
     */
    ImporterContext getContext();
}
