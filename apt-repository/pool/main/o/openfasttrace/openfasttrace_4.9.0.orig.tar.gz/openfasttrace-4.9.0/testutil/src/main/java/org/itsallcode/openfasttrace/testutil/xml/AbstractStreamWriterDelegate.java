package org.itsallcode.openfasttrace.testutil.xml;

import javax.xml.namespace.NamespaceContext;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

/**
 * This interface allows intercepting calls to a stream writer, pre-processing
 * them and then handing the rest of the work of to a given delegate.
 */
public abstract class AbstractStreamWriterDelegate implements XMLStreamWriter
{
    /** Stream writer to delegate to. */
    protected XMLStreamWriter out;

    /**
     * Creates a new instance of the delegate.
     *
     * @param out
     *            stream writer to delegate to
     */
    protected AbstractStreamWriterDelegate(final XMLStreamWriter out)
    {
        this.out = out;
    }

    @Override
    public Object getProperty(final String name)
    {
        return this.out.getProperty(name);
    }

    @Override
    public NamespaceContext getNamespaceContext()
    {
        return this.out.getNamespaceContext();
    }

    @Override
    public void setNamespaceContext(final NamespaceContext context) throws XMLStreamException
    {
        this.out.setNamespaceContext(context);
    }

    @Override
    public void setDefaultNamespace(final String uri) throws XMLStreamException
    {
        this.out.setDefaultNamespace(uri);
    }

    @Override
    public void writeStartDocument() throws XMLStreamException
    {
        this.out.writeStartDocument();
    }

    @Override
    public void writeStartDocument(final String version) throws XMLStreamException
    {
        this.out.writeStartDocument(version);
    }

    @Override
    public void writeStartDocument(final String encoding, final String version)
            throws XMLStreamException
    {
        this.out.writeStartDocument(encoding, version);
    }

    @Override
    public void writeDTD(final String dtd) throws XMLStreamException
    {
        this.out.writeDTD(dtd);
    }

    @Override
    public void writeProcessingInstruction(final String target) throws XMLStreamException
    {
        this.out.writeProcessingInstruction(target);
    }

    @Override
    public void writeProcessingInstruction(final String target, final String data)
            throws XMLStreamException
    {
        this.out.writeProcessingInstruction(target, data);
    }

    @Override
    public void writeComment(final String data) throws XMLStreamException
    {
        this.out.writeComment(data);
    }

    @Override
    public void writeEmptyElement(final String localName) throws XMLStreamException
    {
        this.out.writeEmptyElement(localName);
    }

    @Override
    public void writeEmptyElement(final String namespaceURI, final String localName)
            throws XMLStreamException
    {
        this.out.writeEmptyElement(namespaceURI, localName);
    }

    @Override
    public void writeEmptyElement(final String prefix, final String localName,
            final String namespaceURI) throws XMLStreamException
    {
        this.out.writeEmptyElement(prefix, localName, namespaceURI);
    }

    @Override
    public void writeStartElement(final String localName) throws XMLStreamException
    {
        this.out.writeStartElement(localName);
    }

    @Override
    public void writeStartElement(final String namespaceURI, final String localName)
            throws XMLStreamException
    {
        this.out.writeStartElement(namespaceURI, localName);
    }

    @Override
    public void writeStartElement(final String prefix, final String localName,
            final String namespaceURI) throws XMLStreamException
    {
        this.out.writeStartElement(prefix, localName, namespaceURI);
    }

    @Override
    public void writeDefaultNamespace(final String namespaceURI) throws XMLStreamException
    {
        this.out.writeDefaultNamespace(namespaceURI);
    }

    @Override
    public void writeNamespace(final String prefix, final String namespaceURI)
            throws XMLStreamException
    {
        this.out.writeNamespace(prefix, namespaceURI);
    }

    @Override
    public String getPrefix(final String uri) throws XMLStreamException
    {
        return this.out.getPrefix(uri);
    }

    @Override
    public void setPrefix(final String prefix, final String uri) throws XMLStreamException
    {
        this.out.setPrefix(prefix, uri);
    }

    @Override
    public void writeAttribute(final String localName, final String value) throws XMLStreamException
    {
        this.out.writeAttribute(localName, value);
    }

    @Override
    public void writeAttribute(final String namespaceURI, final String localName,
            final String value) throws XMLStreamException
    {
        this.out.writeAttribute(namespaceURI, localName, value);
    }

    @Override
    public void writeAttribute(final String prefix, final String namespaceURI,
            final String localName, final String value) throws XMLStreamException
    {
        this.out.writeAttribute(prefix, namespaceURI, localName, value);
    }

    @Override
    public void writeCharacters(final String text) throws XMLStreamException
    {
        this.out.writeCharacters(text);
    }

    @Override
    public void writeCharacters(final char[] text, final int start, final int len)
            throws XMLStreamException
    {
        this.out.writeCharacters(text, start, len);
    }

    @Override
    public void writeCData(final String data) throws XMLStreamException
    {
        this.out.writeCData(data);
    }

    @Override
    public void writeEntityRef(final String name) throws XMLStreamException
    {
        this.out.writeEntityRef(name);
    }

    @Override
    public void writeEndElement() throws XMLStreamException
    {
        this.out.writeEndElement();
    }

    @Override
    public void writeEndDocument() throws XMLStreamException
    {
        this.out.writeEndDocument();
    }

    @Override
    public void flush() throws XMLStreamException
    {
        this.out.flush();
    }

    @Override
    public void close() throws XMLStreamException
    {
        this.out.close();
    }
}
