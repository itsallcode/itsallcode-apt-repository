package org.itsallcode.openfasttrace.core;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.itsallcode.openfasttrace.core.SpecificationItemAssertions.*;
import static org.itsallcode.openfasttrace.testutil.core.SampleArtifactTypes.*;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.*;

import java.util.List;

import org.itsallcode.openfasttrace.api.core.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

// [utest->dsn~linked-specification-item~1]
@ExtendWith(MockitoExtension.class)
class TestLinkedSpecificationItem
{
    private LinkedSpecificationItem linkedItem;
    private LinkedSpecificationItem coveredLinkedItem;
    private LinkedSpecificationItem otherLinkedItem;

    @Mock
    private SpecificationItem itemMock, coveredItemMock, otherItemMock;

    @BeforeEach
    void prepareAllTests()
    {
        this.linkedItem = new LinkedSpecificationItem(this.itemMock);
        this.coveredLinkedItem = new LinkedSpecificationItem(this.coveredItemMock);
        this.otherLinkedItem = new LinkedSpecificationItem(this.otherItemMock);
        lenient().when(this.itemMock.getStatus()).thenReturn(ItemStatus.APPROVED);
        lenient().when(this.itemMock.getId()).thenReturn(SpecificationItemId.parseId("a~item~1"));
        lenient().when(this.coveredItemMock.getId()).thenReturn(SpecificationItemId.parseId("a~covered~1"));
        lenient().when(this.otherItemMock.getId()).thenReturn(SpecificationItemId.parseId("a~other~1"));
    }

    @Test
    void testCreateLinkedSpecificationItem()
    {
        assertThat(this.linkedItem.getItem(), equalTo(this.itemMock));
    }

    @Test
    void testLinkWithStatus()
    {
        this.linkedItem.addLinkToItemWithStatus(this.linkedItem, LinkStatus.COVERS);
        assertThat(this.linkedItem.getLinksByStatus(LinkStatus.COVERS),
                containsInAnyOrder(this.linkedItem));
    }

    @Test
    void testGetCoveredArtifactTypes()
    {
        when(this.coveredItemMock.getArtifactType()).thenReturn(UMAN);
        this.linkedItem.addLinkToItemWithStatus(coveredLinkedItem, LinkStatus.COVERED_SHALLOW);
        when(this.coveredItemMock.getArtifactType()).thenReturn(REQ);
        this.linkedItem.addLinkToItemWithStatus(coveredLinkedItem, LinkStatus.COVERED_SHALLOW);
        assertItemHasCoveredArtifactTypes(this.linkedItem, UMAN, REQ);
    }

    @Test
    void testGetUncoveredArtifactTypes()
    {
        when(this.itemMock.getNeedsArtifactTypes()).thenReturn(List.of(UMAN, REQ));
        when(this.coveredItemMock.getArtifactType()).thenReturn(UMAN);
        this.linkedItem.addLinkToItemWithStatus(coveredLinkedItem, LinkStatus.COVERED_SHALLOW);
        assertItemHasUncoveredArtifactTypes(this.linkedItem, REQ);
    }

    @Test
    void testGetOverCoveredArtifactTypes()
    {
        when(this.coveredLinkedItem.getArtifactType()).thenReturn(REQ);
        this.linkedItem.addLinkToItemWithStatus(this.coveredLinkedItem, LinkStatus.COVERED_UNWANTED);
        assertItemHasOvercoveredArtifactTypes(this.linkedItem, REQ);
    }

    @Test
    void testIsCoveredShallow_Ok()
    {
        when(this.itemMock.getNeedsArtifactTypes()).thenReturn(List.of(UMAN, IMPL));
        when(this.coveredItemMock.getArtifactType()).thenReturn(UMAN);
        this.linkedItem.addLinkToItemWithStatus(coveredLinkedItem, LinkStatus.COVERED_SHALLOW);
        when(this.coveredItemMock.getArtifactType()).thenReturn(IMPL);
        this.linkedItem.addLinkToItemWithStatus(coveredLinkedItem, LinkStatus.COVERED_SHALLOW);
        assertItemCoveredShallow(this.linkedItem, true);
    }

    @Test
    void testIsCoveredShallow_NotOk_WrongCoverage()
    {
        when(this.itemMock.getNeedsArtifactTypes()).thenReturn(List.of(UMAN, IMPL));
        when(this.coveredItemMock.getArtifactType()).thenReturn(UMAN);
        this.linkedItem.addLinkToItemWithStatus(coveredLinkedItem, LinkStatus.COVERED_SHALLOW);
        when(this.coveredItemMock.getArtifactType()).thenReturn(REQ);
        this.linkedItem.addLinkToItemWithStatus(coveredLinkedItem, LinkStatus.COVERED_SHALLOW);
        assertItemCoveredShallow(this.linkedItem, false);
    }

    @Test
    void testIsCoveredShallow_NotOk_MissingCoverage()
    {
        when(this.itemMock.getNeedsArtifactTypes()).thenReturn(List.of(UMAN, IMPL));
        when(this.coveredItemMock.getArtifactType()).thenReturn(UMAN);
        this.linkedItem.addLinkToItemWithStatus(coveredLinkedItem, LinkStatus.COVERED_SHALLOW);
        assertItemCoveredShallow(this.linkedItem, false);
    }

    private void prepareCoverThis()
    {
        when(this.itemMock.getNeedsArtifactTypes()).thenReturn(List.of(IMPL));
        lenient().when(this.itemMock.getArtifactType()).thenReturn(DSN);
        when(this.coveredItemMock.getArtifactType()).thenReturn(IMPL);
        this.linkedItem.addLinkToItemWithStatus(this.coveredLinkedItem, LinkStatus.COVERED_SHALLOW);
    }

    // [utest->dsn~tracing.defect-items~2]
    @Test
    void testIsDefect_False()
    {
        prepareCoverThis();
        assertItemDefect(this.linkedItem, false);
    }

    // [utest->dsn~tracing.defect-items~2]
    @Test
    void testIsDefect_TrueBecauseOfDuplicates()
    {
        this.linkedItem.addLinkToItemWithStatus(this.otherLinkedItem, LinkStatus.DUPLICATE);
        assertItemDefect(this.linkedItem, true);
    }

    // [utest->dsn~tracing.defect-items~2]
    @Test
    void testIsDefect_TrueBecauseOfBadLink()
    {
        for (final LinkStatus status : LinkStatus.values())
        {
            final LinkedSpecificationItem item = new LinkedSpecificationItem(this.itemMock);
            item.addLinkToItemWithStatus(this.otherLinkedItem, status);
            final boolean expected = (status != LinkStatus.COVERS)
                    && (status != LinkStatus.COVERED_SHALLOW);
            assertThat("for " + status, item.isDefect(), equalTo(expected));
        }
    }

    @Test
    // [utest->dsn~tracing.defect-items~2]
    void testIsDefect_FalseBecauseRejected()
    {
        final LinkedSpecificationItem item = new LinkedSpecificationItem(this.itemMock);
        when(this.itemMock.getStatus()).thenReturn(ItemStatus.REJECTED);
        item.addLinkToItemWithStatus(this.otherLinkedItem, LinkStatus.COVERED_OUTDATED);
        assertItemDefect(item, false);
    }

    @Test
    void testCountOutgoingLinks()
    {
        linkToNewItemsWithStatus(LinkStatus.COVERS, LinkStatus.PREDATED, LinkStatus.OUTDATED,
                LinkStatus.UNWANTED, LinkStatus.ORPHANED, LinkStatus.AMBIGUOUS);

        assertAll(() -> assertItemOutgoingLinkCount(this.linkedItem, 6),
                () -> assertItemOutgoingBadLinkCount(this.linkedItem, 5));
    }

    private void linkToNewItemsWithStatus(final LinkStatus... status)
    {
        for (final LinkStatus linkStatus : status)
        {
            linkToNewItemWithStatus(linkStatus);
        }
    }

    private void linkToNewItemWithStatus(final LinkStatus status)
    {
        final SpecificationItem item = mock(SpecificationItem.class);
        this.linkedItem.addLinkToItemWithStatus(new LinkedSpecificationItem(item), status);
    }

    @Test
    void testCountIncomingLinks()
    {
        linkToNewItemsWithStatus(LinkStatus.COVERED_SHALLOW, LinkStatus.COVERED_PREDATED,
                LinkStatus.COVERED_OUTDATED, LinkStatus.COVERED_UNWANTED);

        assertAll(() -> assertItemIncomingLinkCount(this.linkedItem, 4),
                () -> assertItemIncomingBadLinkCount(this.linkedItem, 3));
    }

    @Test
    void testCountDuplicateLinks()
    {
        this.linkedItem.addLinkToItemWithStatus(this.coveredLinkedItem, LinkStatus.COVERS);
        this.linkedItem.addLinkToItemWithStatus(this.linkedItem, LinkStatus.DUPLICATE);
        this.linkedItem.addLinkToItemWithStatus(this.otherLinkedItem, LinkStatus.DUPLICATE);
        assertThat(this.linkedItem.countDuplicateLinks(), equalTo(2));
    }

    @Test
    void testGetTitleWithFallback_HasTitle()
    {
        final String expectedReturn = "title";
        when(this.itemMock.getTitle()).thenReturn(expectedReturn);
        assertThat(this.linkedItem.getTitleWithFallback(), equalTo(expectedReturn));
    }

    @Test
    void testGetTitle()
    {
        when(this.itemMock.getTitle()).thenReturn("title");
        assertThat(this.linkedItem.getTitle(), equalTo("title"));
    }

    @Test
    void testGetTitleWithFallback_HasNoTitle()
    {
        when(this.itemMock.getTitle()).thenReturn(null);
        when(this.itemMock.getId()).thenReturn(SpecificationItemId.parseId("foo~id-name~1"));
        assertThat(this.linkedItem.getTitleWithFallback(), equalTo("id-name"));
    }

    @Test
    void testGetTitleWithFallback_HasEmptyTitle()
    {
        when(this.itemMock.getTitle()).thenReturn("");
        when(this.itemMock.getId()).thenReturn(SpecificationItemId.parseId("foo~id-name~1"));
        assertThat(this.linkedItem.getTitleWithFallback(), equalTo("id-name"));
    }

    @Test
    void testGetTitleWithFallback_HasNothing()
    {
        when(this.itemMock.getTitle()).thenReturn("");
        when(this.itemMock.getId()).thenReturn(null);
        assertThat(this.linkedItem.getTitleWithFallback(), equalTo("???"));
    }

    @Test
    void testGetTracedLinks()
    {
        this.linkedItem.addLinkToItemWithStatus(this.coveredLinkedItem, LinkStatus.COVERS);
        this.linkedItem.addLinkToItemWithStatus(this.linkedItem, LinkStatus.ORPHANED);
        final List<TracedLink> links = this.linkedItem.getTracedLinks();
        final TracedLink expectedLinkA = new TracedLink(this.linkedItem, LinkStatus.ORPHANED);
        final TracedLink expectedLinkB = new TracedLink(this.coveredLinkedItem, LinkStatus.COVERS);
        assertThat(links, containsInAnyOrder(expectedLinkA, expectedLinkB));
    }

    @Test
    void testHasLinks_InitiallyFalse()
    {
        assertThat(this.linkedItem.hasLinks(), equalTo(false));
    }

    @Test
    void testGetLinksForStatus_InitiallyEmpty()
    {
        assertThat(this.linkedItem.getLinksByStatus(LinkStatus.AMBIGUOUS), empty());
    }

    @Test
    void testHasLinks()
    {
        this.linkedItem.addLinkToItemWithStatus(this.otherLinkedItem, LinkStatus.AMBIGUOUS);
        assertThat(this.linkedItem.hasLinks(), equalTo(true));
    }

    @Test
    void testGetArtifactType()
    {
        final String expectedArtifactType = "atype";
        when(this.itemMock.getArtifactType()).thenReturn(expectedArtifactType);
        assertThat(this.linkedItem.getArtifactType(), equalTo(expectedArtifactType));
    }

    @Test
    void testGetName()
    {
        final String expectedName = "name";
        when(this.itemMock.getName()).thenReturn(expectedName);
        assertThat(this.linkedItem.getName(), equalTo(expectedName));
    }

    @Test
    void testGetRevision()
    {
        final int expectedRevision = 1024;
        when(this.itemMock.getRevision()).thenReturn(expectedRevision);
        assertThat(this.linkedItem.getRevision(), equalTo(expectedRevision));
    }
}
