package org.itsallcode.openfasttrace.core;

import java.util.*;
import java.util.stream.Collectors;

import org.itsallcode.openfasttrace.api.core.*;

/**
 * An idex for {@link LinkedSpecificationItem} that allows retrieving items by
 * {@link SpecificationItemId}, optionally ignoring the revision.
 */
public final class LinkedItemIndex
{
    private final Map<SpecificationItemId, LinkedSpecificationItem> idIndex;
    private final Map<SpecificationItemIdWithoutVersion, List<LinkedSpecificationItem>> idIndexIgnoringVersion;

    private LinkedItemIndex(final Map<SpecificationItemId, LinkedSpecificationItem> idIndex,
            final Map<SpecificationItemIdWithoutVersion, List<LinkedSpecificationItem>> idIndexIgnoringVersion)
    {
        this.idIndex = idIndex;
        this.idIndexIgnoringVersion = idIndexIgnoringVersion;
    }

    /**
     * Create a new index containing the given items.
     * 
     * @param items
     *            the items to add to the new index.
     * @return a new index.
     */
    public static LinkedItemIndex create(final List<SpecificationItem> items)
    {
        return createFromWrappedItems(wrapItems(items));
    }

    private static List<LinkedSpecificationItem> wrapItems(final List<SpecificationItem> items)
    {
        return items.stream().map(LinkedSpecificationItem::new).toList();
    }

    /**
     * Create a new index containing the given wrapped items.
     * 
     * @param wrappedItems
     *            the items to add to the new index.
     * @return a new index.
     */
    public static LinkedItemIndex createFromWrappedItems(
            final List<LinkedSpecificationItem> wrappedItems)
    {
        return new LinkedItemIndex( //
                createIdIndex(wrappedItems), //
                createIdIndexIgnoringVersion(wrappedItems));

    }

    private static Map<SpecificationItemIdWithoutVersion, List<LinkedSpecificationItem>> createIdIndexIgnoringVersion(
            final List<LinkedSpecificationItem> wrappedItems)
    {
        return wrappedItems.stream()
                .collect(Collectors.groupingBy(SpecificationItemIdWithoutVersion::new));
    }

    private static Map<SpecificationItemId, LinkedSpecificationItem> createIdIndex(
            final List<LinkedSpecificationItem> wrappedItems)
    {
        return wrappedItems.stream().collect(Collectors.toMap(LinkedSpecificationItem::getId, //
                item -> item, //
                LinkedItemIndex::handleDuplicates));
    }

    // [impl->dsn~tracing.tracing.duplicate-items~1]
    private static LinkedSpecificationItem handleDuplicates(final LinkedSpecificationItem item1,
            final LinkedSpecificationItem item2)
    {
        item1.addLinkToItemWithStatus(item2, LinkStatus.DUPLICATE);
        item2.addLinkToItemWithStatus(item1, LinkStatus.DUPLICATE);
        return item1;
    }

    /**
     * Get the total number of items in this index.
     * 
     * @return the total number of items in this index.
     */
    public int size()
    {
        return this.idIndex.size();
    }

    /**
     * Get an item by id.
     * 
     * @param id
     *            the item id.
     * @return the item with the given id or {@code null} if no item exists.
     */
    public LinkedSpecificationItem getById(final SpecificationItemId id)
    {
        return this.idIndex.get(id);
    }

    /**
     * Get number of IDs ignoring the version.
     * 
     * @return the number of IDs ignoring the version.
     */
    public int sizeIgnoringVersion()
    {
        return this.idIndexIgnoringVersion.size();
    }

    /**
     * Get all items for the given ID, ignoring the version.
     * 
     * @param id
     *            the item id.
     * @return the item with the given id or {@code null} if no item exists.
     */
    public List<LinkedSpecificationItem> getByIdIgnoringVersion(final SpecificationItemId id)
    {
        final List<LinkedSpecificationItem> items = this.idIndexIgnoringVersion
                .get(new SpecificationItemIdWithoutVersion(id));
        return items == null ? Collections.emptyList() : items;
    }

    static final class SpecificationItemIdWithoutVersion implements Comparable<SpecificationItemIdWithoutVersion>
    {
        private final String name;
        private final String artifcatType;

        public SpecificationItemIdWithoutVersion(final SpecificationItemId id)
        {
            this.name = id.getName();
            this.artifcatType = id.getArtifactType();
        }

        public SpecificationItemIdWithoutVersion(final LinkedSpecificationItem linkedItem)
        {
            this(linkedItem.getId());
        }

        public String getName() {
            return this.name;
        }

        public String getArtifcatType() {
            return this.artifcatType;
        }

        @Override
        public int hashCode()
        {
            return Objects.hash(this.artifcatType, this.name);
        }

        @Override
        public boolean equals(final Object other) {
            if (!(other instanceof final SpecificationItemIdWithoutVersion that)) {
                return false;
            }
            return Objects.equals(name, that.name) && Objects.equals(artifcatType, that.artifcatType);
        }

        @Override
        public int compareTo(final SpecificationItemIdWithoutVersion other) {
            return Comparator.comparing(SpecificationItemIdWithoutVersion::getArtifcatType)
                    .thenComparing(SpecificationItemIdWithoutVersion::getName)
                    .compare(this, other);
        }
    }
}
