package org.itsallcode.openfasttrace.core.importer;

import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import org.itsallcode.openfasttrace.api.importer.*;
import org.itsallcode.openfasttrace.api.importer.input.InputFile;
import org.itsallcode.openfasttrace.core.serviceloader.InitializingServiceLoader;
import org.itsallcode.openfasttrace.core.serviceloader.Loader;

/**
 * This class is responsible for finding the matching {@link ImporterFactory}
 * for a given {@link Path}.
 */
public class ImporterFactoryLoader
{
    private static final Logger LOG = Logger.getLogger(ImporterFactoryLoader.class.getName());
    private final Loader<ImporterFactory> serviceLoader;

    /**
     * Creates a new loader.
     * 
     * @param serviceLoader
     *            the loader used for locating importers.
     */
    ImporterFactoryLoader(final Loader<ImporterFactory> serviceLoader)
    {
        this.serviceLoader = serviceLoader;
    }

    /**
     * Create a new loader for the given context.
     * 
     * @param context
     *            context for the new loader
     */
    public ImporterFactoryLoader(final ImporterContext context)
    {
        // [impl->dsn~plugins.loading.plugin-types~1]
        this(InitializingServiceLoader.load(ImporterFactory.class, context));
    }

    /**
     * Finds a matching {@link ImporterFactory} that can handle the given
     * {@link Path}. If no {@link ImporterFactory} is found, this throws an
     * {@link ImporterException}.
     *
     * @param file
     *            the file for which to get a {@link ImporterFactory}.
     * @return a matching {@link ImporterFactory} that can handle the given
     *         {@link Path}
     * @throws ImporterException
     *             when no {@link ImporterFactory} is found.
     */
    public Optional<ImporterFactory> getImporterFactory(final InputFile file)
    {
        final List<ImporterFactory> matchingImporters = getMatchingFactoriesInOrderOfPriority(file);
        if (matchingImporters.isEmpty())
        {
            LOG.info(() -> "Found no matching importer for file '" + file + "'");
            return Optional.empty();
        }
        else
        {
            return Optional.of(matchingImporters.get(0));
        }
    }

    /**
     * Check if any {@link ImporterFactory} supports importing the given
     * {@link InputFile}.
     * 
     * @param file
     *            the file for which to check if an importer exists.
     * @return {@code true} if an importer exists, else {@code false}.
     */
    public boolean supportsFile(final InputFile file)
    {
        final boolean supported = !getMatchingFactoriesInOrderOfPriority(file).isEmpty();
        LOG.finest(() -> "File " + file + " is supported = " + supported);
        return supported;
    }

    private List<ImporterFactory> getMatchingFactoriesInOrderOfPriority(final InputFile file)
    {
        final List<ImporterFactory> allFactories = this.serviceLoader.load().toList();
        if (allFactories.isEmpty())
        {
            throw new ImporterException("No importers discovered. If you are running OpenFastTrace as a library, "
                    + "ensure that the thread context classloader has access to the importer implementations.");
        }
        return allFactories.stream()
                .filter(f -> f.supportsFile(file))
                .sorted(Comparator.comparingInt(ImporterFactory::getPriority))
                .toList();
    }
}
