<head>
    <link href="oft_spec.css" rel="stylesheet" />
    <title>OpenFastTrace Design</title>
</head>

# Introduction

## Acknowledgments

This document's structure is derived from the "[arc42][bib.arc42]" architectural template by Dr. Gernot Starke, Dr. Peter Hruschka.

If you build your own modifications based on this document, please keep the attrbiutions.

## Terminology
The terminology from the [system requirement specification][bib.srs] applies.

## Conventions

### Syntax Definitions
Syntax definitions in this document use the [Augmented Backus-Naur Form][bib.abnf].

The following definitions are used frequently throughout the document:

* ANY - any valid character
* LINEBREAK = the line break character of the platform

# Constraints

# Solution Ideas and Strategy

## Requirement tracing

The algorithm that checks the requirement links has to follow each link between requester and provider at least once.

Given:

  r<sub>n</sub>, n ∊ {1..N}

  p<sub>m</sub>, m ∊ {1..M}

  a<sub>n,l</sub>, l ∊ {1..L<sub>n</sub>}

  c<sub>m,k</sub>, k ∊ {1..M<sub>m</sub>}

Where _r_ are the requesters, _p_ the providers, _a_ artifacts required by providers and _c_ the coverage provided.

The number of forward links results to:

  f = Σ<sup>N</sup><sub>n = 1</sub> ( L<sub>n</sub> )

The number of backward links is:

  b = Σ<sup>M</sup><sub>n = 1</sub> ( K<sub>n</sub> )

### Lookups in the Naive Approach

The naive approach is to iterate over all required artifacts in all requesters and for each iterate over the complete set of providers to see if coverage exists.

If we assume a scenario where the coverage is 100% and a provider is found in average after iterating over half the providers this gives us the following number of Lookups _l_:

  l = f p / 2

Assuming that each requester needs to be covered by an average of _A_ artifacts we get:

  f = r A

  l = ( r  A ) p / 2

Assuming further that each provider has an average of _C_ back links to provide coverage we further get:

  p = r C

  l = ( r A ) ( r C ) / 2 = r² A C / 2

Note that _A_ and _C_ can be considered to have a small range in a typical project, depending only on the working style and not on the number of requirements the project need to handle.

In effect the lookup using the naive approach results in a complexity of O(n²). Not good.

### Lookups With an Index

If instead of relying on a linear search of all providers, we use an index. We saw earlier that iterating over the requesters results in a complexity of O(n). A proper index lookup should give O(log n) in the worst case. That leaves us with a complexity of O(n log(n)). Better.

### Choosing the Index

Since the specification item IDs inherently look similar, load tests need to show which kind of index is best balanced and has the optimal access time.

# Context

## Technical Constraints

## Conventions

# Building Block View

## Plugin Loader
The plugin loader discovers and loads available plugins.

## Importers
For each specification artifact type OFT uses an importer. The importer uses the specification artifact as data source and reads specification items from it.

### Shared Coverage Tag Parser

The `importer/tag-importer-common` module provides the reusable line scanning and coverage-tag parsing used by importers. Its public API consists of `LineReader`, which forwards input lines to a consumer, and `CoverageTagParser`, which recognizes coverage tags.

The tag importer remains responsible for selecting its input files and creating the shared parser. Parsing implementation classes remain encapsulated in the shared module so that future importers can reuse the same coverage-tag semantics without depending on tag-importer internals.

## Import Event Listener
Importers emit events if they find parts of a [specification item](#specification-item) in the artifact they are importing.

### Specification List Builder
The specification list builder is an import event listener that creates a list of specification items from import events.

#### Located Specification Item ID Storage
`dsn~located-specification-item-id-storage~1`

`SpecificationItem` and `SpecificationListBuilder` preserve the individual
declared, Covers, and Depends occurrences as `LocatedSpecificationItemId`
values while retaining compatible item ID accessors. Located-ID lists are
immutable when observed through the public API.

Covers:

* req~located-specification-item-ids~1

Needs: impl, utest

#### Text Source Ranges
`dsn~located-specification-item-id-text-ranges~1`

Text importers create zero-based UTF-16, start-inclusive and end-exclusive
ranges for source ID occurrences and their represented components. Equal
item IDs at distinct source occurrences remain separate values.

Needs: impl, utest

#### Coverage-tag Source Ranges
`dsn~located-specification-item-id-tag-ranges~1`

The full coverage-tag importer locates source-backed declared and covered ID
components. It leaves component ranges absent when a tag generates the
corresponding ID component. The short coverage-tag importer creates item
IDs without source ranges.

Needs: impl, utest

#### SpecObject ID Occurrences
`dsn~located-specification-item-id-specobject~1`

The SpecObject importer emits located declared, covered, and dependency IDs
without ranges because its XML event model does not expose character offsets.

Needs: impl, utest

## Command Line Interpreter
The command line interpreter (CLI) takes parameters given to OFT and parses them. It is responsible for making sense of the parameter contents and issuing help and error messages about the command line syntax.

## Linker
The linker is responsible for turning the imported [specification items](#specification-item) collected by the [importers](#importers) into [linked specification items](#linked-specification-item).

## Tracer
The tracer consumes the list of [linked specification items](#linked-specification-item) and evaluates the link status for each link.

## Reporter
The reporter consumes the link status list and the specification item list and generates a report in the chosen output format.

API users select reporters via their name as strings. This allows plugging in custom reporters in a loosely coupled fashion.

## Exporters
The exporter transforms the internal representation of [specification items](#specification-item) into the desired target format (e.g. Markdown).

API users select exporters via their name as strings.

# Runtime View

## Discovering and Loading Plugins
`dsn~plugins.loading~1`

OFT loads plugins at startup from these locations:
* Plugins included with OFT from the current ClassPath
* Third party plugins from folder `$HOME/.oft/plugins/<plugin-name>/*.jar`

Rationale:

* A plugin may consist of multiple JARs, e.g. the plugin itself and it's dependencies.
* A plugin might need extra resources

Covers:

* [`req~plugins.loading~1`](system_requirements.md#loading-plugins)

Needs: impl, utest, itest

### Plugin Loader Uses Separate ClassLoaders
`dsn~plugins.loading.separate-classloader~1`

The Plugin loader uses a separate ClassLoader for each plugin.

Rationale:

Separating plugins from each other avoids conflicts between potentially duplicate classes in plugin.

Covers:

* [`req~plugins.loading~1`](system_requirements.md#loading-plugins)

Needs: impl, utest

### Loader Supports Plugin Types
`dsn~plugins.loading.plugin-types~1`

The Plugin loader supports loading factories for the following plugin types:

* Importers: `org.itsallcode.openfasttrace.api.importer.ImporterFactory`
* Exporters: `org.itsallcode.openfasttrace.api.exporter.ExporterFactory`
* Reports: `org.itsallcode.openfasttrace.api.report.ReporterFactory`

Reporter implementations usually extend `org.itsallcode.openfasttrace.api.report.AbstractReporterFactory`
to reuse standard reporter context handling while keeping `ReporterFactory` as the service type.

Exporter implementations usually extend `org.itsallcode.openfasttrace.api.exporter.AbstractExporterFactory`
to reuse standard exporter and context handling while keeping `ExporterFactory` as the service type.

Covers:
* [`req~plugins.types~1`](system_requirements.md#supported-plugin-types)

Needs: impl, itest

## Import

Depending on the source format, a variety of [importers](#importers) takes care of reading the input [specification items](#specification-item). Each importer emits events which an [import event listener](#import-event-listener) consumes.

The listener handles Common parts of the import like filtering out unnecessary items or attributes.

The following sequence diagram illustrates the interaction between `MultiFileImporter`, `ImporterFactoryLoader`, `ImporterFactory`, and `Importer` during the import process:

```puml
@startuml
participant MultiFileImporterImpl as MFI
participant ImporterFactoryLoader as IFL
participant ImporterFactory as IF
participant Importer as I
participant SpecificationListBuilder as SLB

[-> MFI : importFile(file)
activate MFI
MFI -> IFL : getImporterFactory(file)
activate IFL
IFL -> IF : supportsFile(file)
activate IF
return true
IFL -> IF : getPriority()
activate IF
return priority
note over IFL: Choose factory with\nlowest priority value
return factory
MFI -> IF : createImporter(file, specItemBuilder)
activate IF
create I
IF -> I : new
return importer
MFI -> I : runImport()
activate I
I -> SLB : event(item)
activate SLB
return
return
return
@enduml
```

A factory for importers decides which importer to use. When multiple importers support the same file, the one with the lowest priority value (highest precedence) is chosen. Usually, importers are selected based on file extension, but some importers may peek into the file content to determine compatibility.

`ImporterFactory` is the plugin interface discovered by the service loader. Importer implementations in OFT usually extend `AbstractImporterFactory` to reuse the default context handling.

The default priorities for standard importers are:
1. Markdown Importer: 1000
2. reStructuredText Importer: 2000
3. Specobject (ReqM2) Importer: 3000
4. Gherkin Importer: 9000
5. Tag Importer: 10000
6. Zip Importer: 20000

### Gherkin Import

#### Importer Selection
`dsn~gherkin.importer-selection~1`

The Gherkin importer selects `.feature` files with priority 9000, ahead of the Tag Importer. This gives Gherkin syntax ownership to the dedicated importer while retaining the Tag Importer as the fallback for other source files.

Covers:

* `req~gherkin-scenario-import~1`

Needs: impl, utest, itest

#### Streaming Import
`dsn~gherkin.streaming-import~1`

The Gherkin importer scans each input file once and streams non-comment scenario steps into the description until a Gherkin block boundary.

Covers:

* `req~gherkin-scenario-import~1`

Needs: impl, utest

#### ID Detection
`dsn~gherkin.id-detection~1`

The importer imports only scenarios and scenario outlines with exactly one immediately preceding `@id:` tag. It uses the ID tag's line as the item location and the scenario header as the title. Invalid IDs cause only the affected scenario to be skipped. Duplicate item IDs are passed to the OFT core, which validates them after import.

Covers:

* `req~gherkin-scenario-import~1`

Needs: impl, utest

#### Covers Metadata Validation
`dsn~gherkin.covers-metadata-validation~1`

The importer accepts scoped `# Covers:` comments between an ID tag region and its scenario header. Multiple directives accumulate coverage IDs. A malformed Covers directive causes only the affected scenario to be skipped.

Covers:

* `req~gherkin-covers-validation~1`

Needs: impl, utest

#### Needs Metadata Validation
`dsn~gherkin.needs-metadata-validation~1`

The importer accepts at most one scoped `# Needs:` comment between an ID tag region and its scenario header. A malformed or repeated Needs directive causes only the affected scenario to be skipped.

Covers:

* `req~gherkin-needs-validation~1`

Needs: impl, utest

#### Support Coverage Tags
`dsn~gherkin.comment-coverage-tags~1`

The Gherkin importer delegates only comment lines to the shared coverage-tag parser. This preserves basic comment coverage tags without applying their regular expressions to executable Gherkin text.

When a comment tag occurs inside an imported scenario, its listener events are buffered until the scenario ends. The shared parser emits complete specification-item event sequences, so emitting them immediately would interleave them with the open scenario item and corrupt the listener state.

Covers:

* `req~gherkin-comment-coverage-tags~1`

Needs: impl, utest

### ReqM2 File Detection
`dsn~import.reqm2-file-detection~1`

The `SpecobjectImporterFactory` detects ReqM2 files either

1. via the file extension `.oreqm` or
2. via the file extension `.xml` and the presence of the string `<specdocument` within the first 4096 bytes of the file.

Since the Tag Importer also supports `.xml` files but has a higher priority value (10000 vs 3000), `.xml` files containing the `<specdocument` tag will be handled by the Specobject Importer. Only if the file does not contain the tag will it fall back to the Tag Importer.

Covers:

* `req~import.reqm2-file-detection~1`

Needs: impl, utest

### Selective Artifact Type Import

The most resource-friendly way to enable partial tracing is to ignore unnecessary data during import. This way less memory is used up and all subsequent steps are faster.

#### Filtering by Artifact Types During Import
`dsn~filtering-by-artifact-types-during-import~1`

When OFT is configured to restrict inclusion to one or more artifact types the [specification list builder](#specification-list-builder) imports the following elements only if they match at least one of the configured types:

1. "Needs coverage" markers
2. Specification items as a whole
3. Links covering items with this artifact type
4. Dependencies to item with this artifact type

Covers:

* `req~include-only-artifact-types~1`

Needs: impl, utest, itest

#### Filtering by Item Status During Import
`dsn~filtering-by-item-status-during-import~1`

The [specification list builder](#specification-list-builder) can be configured to import a specification item only if its status matches at least one of the configured statuses.

Covers:

* `req~include-only-item-statuses~1`

Needs: impl, utest, itest

#### Filtering by Tags During Import
`dsn~filtering-by-tags-during-import~1`

The [specification list builder](#specification-list-builder) can be configured to import a specification item only if at least one of its tags is contained in the configured set of tags.

Covers:

* `req~include-items-where-at-least-on-tag-matches~1`

Needs: impl, utest, itest

#### Filtering by Tags or no Tags During Import
`dsn~filtering-by-tags-or-no-tags-during-import~1`

The [specification list builder](#specification-list-builder) can be configured to import a specification item only if it either has no tags or at least one of its tags is contained in the configured set of tags.

Covers:

* `req~include-items-that-do-not-have-tags-or-where-at-least-one-tag-matches~1`

Needs: impl, utest, itest

### Line Parser for Lightweight Markup Import

RST and Markdown share a common underlying parser that operates on a line-by-line basis.

##### Markdown Comment Coverage Tags
`dsn~markdown.comment-coverage-tags~1`

For a Markdown input file, the lightweight-markup importer delegates a line to the shared coverage-tag parser only when the complete line is a single-line HTML comment, apart from optional surrounding whitespace. The dedicated Markdown importer keeps its priority ahead of the Tag Importer, and the existing markup state machine continues to process every input line.

Covers:

* `scn~markdown.comment-coverage-tags~1`

Needs: impl, utest, itest

##### RST Comment Coverage Tags
`dsn~rst.comment-coverage-tags~1`

For an RST input file, the lightweight-markup importer delegates a line to the shared coverage-tag parser only when it begins with optional whitespace, `..`, and whitespace, and is not an RST directive. The dedicated RST importer keeps its priority ahead of the Tag Importer, and the existing markup state machine continues to process every input line.

Covers:

* `scn~rst.comment-coverage-tags~1`

Needs: impl, utest, itest

##### Disabling OFT Parsing for Parts of a Markup File
`dsn~disabling-oft-parsing-for-parts-of-a-markup-file~1`

When it encounters the token `oft:off`, the line parser stops extracting specification items until it

* either encounters the token `oft:on`
* or reaches the end of the current document.

Covers:

* `req~disabling-oft-parsing-for-parts-of-a-markup-file~1`

Needs: impl, utest

## Tracing

### Tracing Needed Coverage
`dsn~tracing.needed-coverage-status~1`

The [linker](#linker) component iterates over all needed artifact types of all specification items and determines if and which coverage exists for each.

Comment:
Note that the linker only takes care of swallow coverage. [Deep coverage](#deep-coverage) is determined by the [tracer](#tracer) component.

Covers:

* `req~tracing.outgoing-coverage-link-status~1`

Needs: utest, impl

### Outgoing Coverage Link Status
`dsn~tracing.outgoing-coverage-link-status~3`

The [linker](#linker) component determines the coverage status of the outgoing link between the provider item and the requester item.

The possible results are:

  1. Covers:    link points to a specification item which wants this coverage
  2. Outdated:  link points to a specification item which has a higher revision number
  3. Predated:  link points to a specification item which has a lower revision number
  4. Ambiguous: link points to a specification item that has duplicates
  5. Orphaned:  link is broken - there is no matching coverage requester
  6. Unwanted:  coverage provider has an artifact type the provider does not want

Covers:

* `req~tracing.outgoing-coverage-link-status~1`

Needs: utest, impl

### Incoming Coverage Link Status
`dsn~tracing.incoming-coverage-link-status~1`

The [linker](#linker) component determines the coverage status of the incoming link between the requester item and the provider item.

The possible results are:

  1. Covered shallow:  coverage provider for a required coverage exists
  2. Covered unwanted: coverage provider covers an artifact type the requester does not want
  3. Covered predated: coverage provider covers a higher revision number than the requester has
  4. Covered outdated: coverage provider covers a lower revision number than the requester has

Covers:

* `req~tracing.incoming-coverage-link-status~1`

Needs: impl, utest

### Deep Coverage
`dsn~tracing.deep-coverage~1`

The [Linked Specification Item](#linked-specification-item) declares itself _covered deeply_ if this item - and all items it needs coverage from - are covered recursively.

Covers:

* `req~tracing.deep-coverage~1`

Needs: impl, utest

### Duplicate Items
`dsn~tracing.tracing.duplicate-items~1`

The [tracer](#tracer) marks a [specification item](#specification-item) as a _duplicate_ if other items with an identical [specification item ID](#specification-item-id) exist.

Covers:

* `req~tracing.duplicate-items~1`

Needs: impl, utest

### Defect Items
`dsn~tracing.defect-items~2`

The [tracer](#tracer) marks a [specification item](#specification-item) as _defect_ if the following criteria apply to the item

    has duplicates
    or (not rejected
        and (any outgoing coverage link has a different status than "Covers"
             or not covered deeply
            )
       )

Covers:

* `req~tracing.defect-items~2`

Needs: impl, utest

### Transitive Defect
`dsn~tracing.transitive-defect~1`

The [tracer](#tracer) identifies a [specification item](#specification-item) as having a _transitive defect_ if it is a [defect item](#defect-items) but none of the direct defect criteria apply.

A transitive defect occurs when a specification item itself fulfills all direct coverage requirements, but at least one of the items it covers (directly or indirectly) is a defect item.

Covers:

* `req~tracing.transitive-defect~1`

Needs: impl, utest

### Link Cycle
`dsn~tracing.link-cycle~1`

The [tracer](#tracer) detects cycles in links between [Linked Specification Items](#linked-specification-item).

Covers:

* `req~tracing.link-cycle~1`

Needs: impl, utest

## Report Verbosity

### Verbosity Level Direct Failures
`dsn~reporting.verbosity.direct-failures~1`

The verbosity level `direct_failures` renders only IDs of items that are not ok and do not have a transitive defect.

Covers:

* `req~reporting.verbosity.direct-failures~1`

Needs: impl, utest

### Verbosity Level Direct Failure Summaries
`dsn~reporting.verbosity.direct-failure-summaries~1`

The verbosity level `direct_failure_summaries` renders only summaries of items that are not ok and do not have a transitive defect.

Covers:

* `req~reporting.verbosity.direct-failure-summaries~1`

Needs: impl, utest

### Verbosity Level Direct Failure Details
`dsn~reporting.verbosity.direct-failure-details~1`

The verbosity level `direct_failure_details` renders only summaries and details of items that are not ok and do not have a transitive defect.

Covers:

* `req~reporting.verbosity.direct-failure-details~1`

Needs: impl, utest

## Tracing Reports

### Plain Text Report

#### Plain Text Report Summary
`dsn~reporting.plain-text.summary~3`

The summary in the plain text report includes:

* Result status
* Total number of specification items
* Total number of direct and transitive defect specification items (if any)

Covers:

* `req~reporting.plain-text.summary~3`

Needs: impl, utest

#### Plain Text Report Specification Item Overview
`dsn~reporting.plain-text.specification-item-overview~2`

An item summary consist in the plain text report includes

  1. Status
  2. Number of broken incoming links
  3. Total number of incoming links
  4. Number of broken outgoing links
  5. Total number of outgoing links
  6. Number of duplicates (not including this item)
  7. ID
  8. Status (unless "approved")
  9. Artifact types indicating coverage

Covers:

* `req~reporting.plain-text.specification-item-overview~2`

Needs: impl, utest

#### Plain Text Report Link Details
`dsn~reporting.plain-text.link-details~1`

The link detail section shows for all links of a specification item:

  1. Incoming / Outgoing as arrow
  2. Link status as symbol
  3. ID of the specification item on the other end of the link

Covers:

* `req~reporting.plain-text.link-details~1`

Needs: impl, utest

#### Plain Text Report Contains Specification Item Origin
`dsn~reporting.plain-text.specification-item-origin~1`

If enabled, the plain text report shows the origin of a specification item

* for files: `<absolute path to file>:<line number>`

Rationale:

This format is recognized by most IDEs and automatically turned into a link in the IDE's console.

Covers:

* `req~reporting.requirement-origin~1`

Needs: impl, utest

#### Plain Text Report Link Contains Specification Item Origin
`dsn~reporting.plain-text.linked-specification-item-origin~1`

If enabled, the links in the plain text report show the origin of a specification item

* for files: `<absolute path to file>:<line number>`

Rationale:

This format is recognized by most IDEs and automatically turned into a link in the IDE's console.

Covers:

* `req~reporting.requirement-origin~1`

Needs: impl, utest

### Plain Text Report ANSI Color
`dsn~reporting.plain-text.ansi-color~1`

The plain text report uses ANSI escape sequences to color the output.

Covers:

* `req~colored-plain-text-report~1`

Needs: impl, utest

### Plain Text Report ANSI Font Style
`dsn~reporting.plain-text.ansi-font-style~1`

The plain text report uses ANSI escape sequences to modify the font style of the output.

Covers:

* `req~colored-plain-text-report~1`
* `req~monochrome-plain-text-report-with-font-style~1`

Needs: impl, utest

#### Plain Text Report Transitive Defect
`dsn~reporting.plain-text.transitive-defect~1`

The plain text report renders the suffix `(transitive)` for transitive defects.
The status `not ok` is rendered in grey for transitive defects.

Covers:

* `req~reporting.plain-text.transitive-defect~1`

Needs: impl, utest


### HTML Report

#### HTML Report Inlines CSS
`dsn~reporting.html.inline_css~1`

OFT inlines the cascading style sheet (CSS) into the HTML report.

Covers:

* `req~reporting.html.single_file~1`

Needs: impl, itest

#### HTML Reports Allows Configuring Details Display Status
`dsn~reporting.html.details-display~1`

OFT allows configuring the specification item detail section display status (expanded or collapsed). Default is collapsed.

Covers:

* [`req~reporting.html.details-display~1`](system_requirements.md#html-report-renders-details-expanded-or-collapsed-initially-as-configured)

Needs: impl, utest

#### HTML Report Escapes HTML Tags
`dsn~reporting.html.escape-html~1`

OFT escapes characters `<` and `>` when rendering the following parts of a specification item to report:

* Title
* Description
* Rationale
* Comment

Rationale:

* This avoids generating invalid HTML when the Markdown contains text like `<section>`.
* Other parts of a specification item (e.g. item ID) don't allow these characters and don't need escaping.

Covers:

* [`req~reporting.html.valid-html~1`](system_requirements.md#html-report-renders-valid-html)

Needs: impl, utest

#### HTML Report Transitive Defect Mark
`dsn~reporting.html.transitive-defect-mark~1`

The HTML report renders the transitive defect mark (❎) for items that have a [transitive defect](#transitive-defect).

Covers:

* `req~reporting.html.transitive-defect-mark~1`

Needs: impl, utest

#### HTML Report Summary
`dsn~reporting.html.summary~2`

The HTML report summary renders the status, the number of total items, a progress bar and the number of direct and transitive defects.

Covers:

* `req~reporting.html.summary~2`

Needs: impl, utest

## Requirement Format Conversion

### ReqM2 Export
`dsn~conversion.reqm2-export~1`

OFT exports to ReqM2's "SpecObject" format.

Comment:
The ReqM2 format is specified in the ReqM2 handbook by Elektrobit.

Covers:

* `req~conversion.reqm2-export~1`

Needs: impl, itest

#### HTML Report Contains Specification Item Origin
`dsn~reporting.html.specification-item-origin~1`

If enabled, the HTML report shows the origin of a specification item as an HTML link pointing to the source.

Covers:

* `req~reporting.requirement-origin~1`

Needs: impl, utest

#### HTML Report Link Contains Specification Item Origin
`dsn~reporting.html.linked-specification-item-origin~1`

If enabled, the links in the plain text report show the origin of a specification item as an HTML link pointing to the source.

Covers:

* `req~reporting.requirement-origin~1`

Needs: impl, utest

# Deployment View

# Concepts

## Data Structures

### Internal Data Structures

#### Specification Item
`dsn~specification-item~3`

A `SpecificationItem` consists of the following parts:

* ID (`SpecificationItemId`)
* Title (`String`, optional)
* Status (`Enum`, optional)
* Description (`String`, optional)
* Rationale (`String`, optional)
* Comment (`String`, optional)
* Source file + line (`String`, `int`, optional)
* Covers (List of `SpecificationItemId`, optional)
* Depends (List of `SpecificationItemId`, optional)
* Needs (List of `String`, optional)
* Tags (List of `String`, optional)
* Forwards (`boolean`, internal)

Comment:

See `req~forwarding_needed_coverage~1` for an explanation of the "forwards" fields meaning.

Covers:

* `req~specification-item~2`
* `req~forwarding_needed_coverage~1`

Needs: impl, utest

#### Linked Specification Item
`dsn~linked-specification-item~1`

A `LinkedSpecificationItem` is a container for a [SpecificationItem](#specification-item) that is enriched with references to other `LinkedSpecificationItem`s.

Rationale:
This allows navigating between specification items.

Covers:

* `req~specification-item~2`

Needs: impl, utest

#### Specification Item ID
`dsn~specification-item-id~1`

A `SpecificationItemId` consists of:

* Artifact type (String)
* name (String)
* revision (number)

Covers:

* `req~specification-item~2`

Needs: impl, utest

### Markdown-style Structures

#### Markdown Specification Item ID Format
`dsn~md.specification-item-id-format~3`

A requirement ID has the following format

    requirement-id = type "~" id "~" revision

    type = 1*ALPHA

    id = id-fragment *("." id-fragment)

    id-fragment = UNICODE_ALPHA *(UNICODE_ALPHA / DIGIT / "_" / "-")

    revision = 1*DIGIT

Rationale:

* The ID may contain unicode letters to allow naming requirements using non-ASCII characters. This makes linking in formats like Markdown or HTML clean and easy.
* Requirement type and revision must be immediately recognizable from the requirement ID.
* The built-in revision number makes links break if a requirement is updated - a desired behavior.

Comment:

Note that the artifact type is integral part of the ID. That means that `dsn~my-requirement~1` is something completely different then `utest~my-requirement~1`. One of the benefits of making the artifact type mandatory part of the ID is that this allows for typical coverage chains like.

    req~my-requirement~2 -> dsn~my-requirement~4 -> impl~my-requirement~4

Otherwise users would be forced to invent different names for each link in the chain.

Covers:

* `req~markdown-standard-syntax~1`

Needs: impl, utest

#### Markdown Specification Item Title
`dsn~md.specification-item-title~1`

If a Markdown title directly precedes a specification item ID, then the Markdown title is used as title for the specification item.

Rationale:

Markdown titles show up in the outline and are a natural way of defining a requirement title.

Covers:

* `req~markdown-standard-syntax~1`
* `req~markdown-outline-readable~1`

Needs: impl, utest

#### Markdown Requirement References
`dsn~md.requirement-references~1`

In Markdown specification item references have the following format:

    reference = (plain-reference / url-style-link)

    plain-reference = requirement-id

    url-style-link = "[" link-text "]" "(" "#" requirement-id ")"

Covers:

* `req~markdown-standard-syntax~1`

Needs: impl, utest

#### Markdown "Covers" list
`dsn~md.covers-list~1`

The Markdown Importer supports the following format for links that cover a different specification item.

    covers-list = covers-header 1*(LINEBREAK covers-line)

    covers-header = "Covers:" *WSP

    covers-line = *WSP "*" *WSP reference

Only one traced reference per line is supported. Any optional text after the reference is ignored if it is separated by at least one whitespace character

Rationale:

Defining a link should be as natural and simple as possible in Markdown. It must also be rendered correctly by a regular Markdown renderer without modifications. Embedding links in lists to define the relationship looks nice and is language independent.

Covers:

* `req~markdown-standard-syntax~1`

Needs: impl, utest

#### Markdown "Depends" List
`dsn~md.depends-list~1`

The Markdown Importer supports the following format for links to a different specification item which the current depends on.

    depends-list = depends-header 1*(LINEBREAK depends-line)

    depends-header = "Depends:" *WSP

    depends-line = *WSP "*" *WSP reference

Only one traced reference per line is supported. Any optional text after the reference is ignored if it is separated by at least one whitespace character

Rationale:

Defining a link should be as natural and simple as possible in Markdown. It must also be rendered correctly by a regular Markdown renderer without modifications. Embedding links in lists to define the relationship looks nice and is language independent.

Covers:

* `req~markdown-standard-syntax~1`

Needs: impl, utest

#### Markdown "Needs" List
`dsn~md.needs-coverage-list~1`

The Markdown Importer supports the following list format for defining the list of artifact types that are needed to fully cover the current specification item.

    needs-list = needs-header 1*(LINEBREAK depends-line)

    needs-header = "Needs:" *WSP

    needs-line = *WSP "*" *WSP reference

Rationale:

This alternative style of the "needs" list provides backward compatibility to Elektrobit's legacy requirement enhanced Markdown format.

Covers:

* `req~markdown-standard-syntax~1`

Needs: impl, utest

#### Markdown "Needs" List
`dsn~md.needs-coverage-list-single-line~2`

The Markdown Importer supports the following format for defining the list of artifact types that are needed to fully cover the current specification item.

    needs-list = "Needs:" *WSP reference *("," *WSP reference)

Rationale:

Unlike references to other requirements, artifact types are usually very short, so it is visually beneficial to use a compact style with a comma separated list in a single line.

Covers:

* `req~markdown-standard-syntax~1`

Needs: impl, utest

#### Markdown Artifact Forwarding Notation
`dsn~md.artifact-forwarding-notation~1`

The Markdown Importer supports forwarding required coverage from one artifact type to one or more different artifact types using the following notation.

    artifact-need-redirection = skipped-artifact-type *WSP "-->" *WSP target-artifact-list
        *WSP ":" *WSP original-requirement-id

    skipped-artifact-type = artifact-type

    target-artifact-list = artifact-type *("," *WSP artifact-type)

    original-requirement-id = requirement-id

The following example shows an architectural specification item that forwards the needed coverage directly to the detailed design and an integration test:

<!-- oft:off -->
    arch --> dsn, itest : req~skip-this-requirement~1
<!-- oft:on -->

Covers:

* `req~artifact-type-forwarding-in-markdown~1`

Needs: impl, utest

### Coverage Tag Format

#### Full Coverage Tag Format
`dsn~import.full-coverage-tag~1`

OFT imports coverage tags in the full tag format:

    full-tag = "[" *WSP reference "->" requirement-id "]"

Covers:

* `req~import.full-coverage-tag-format~2`

Needs: impl, utest

#### Full Coverage Tag Format With Needed Coverage
`dsn~import.full-coverage-tag-with-needed-coverage~1`

OFT imports coverage tags in the full tag format with a list of required/needed artifact types:

    full-tag-with-needed-coverage = "[" *WSP reference *WSP "->" *WSP requirement-id
    *WSP ">>" *WSP artifact-type *WSP *("," *WSP artifact-type) "]"

Rationale:

The Tag importer is the catch all solution for all file formats that don't have a dedicated importer. We want to allow specification items imported via Tag importer to be intermediate nodes in the specification tree, instead of limiting them to leaves in the specification tree. Because leaves can only cover other specification items, but not require coverage.

Especially when used for design document files like UML models, requiring coverage is useful.

Covers:

* `req~import.full-coverage-tag-format~2`

Needs: impl, utest

#### Full Coverage Tag Format Allows Multiple Coverage
`dsn~import.full-coverage-tag-multiple-needed-coverage~1`

OFT imports full coverage tags with multiple need coverage ids:

    full-tag-multiple-coverage-id =
        "[" *WSP reference *WSP "->" *WSP requirement-id *WSP *("," *WSP requirement-id) *WSP "]"

Rationale:

An item can cover multiple IDs. This avoids creating multiple IDs for the same item solely to represent multiple coverage relations. It also reduces the number of IDs that related items must reference for complete coverage, improving readability and maintainability.

Covers:

* `req~import.full-coverage-tag-format~2`

Needs: impl, utest

#### Full Coverage Tag Format Allows Specifying a Revision
`dsn~import.full-coverage-tag-with-revision~1`

OFT imports full coverage tags with an optional revision:

    full-tag-with-revision = "[" *WSP reference "~" "~" revision "->" requirement-id "]"

    full-tag-with-revision-with-needed-coverage = "[" *WSP reference "~" "~" revision *WSP "->" *WSP requirement-id
    *WSP ">>" *WSP artifact-type *WSP *("," *WSP artifact-type) "]"

Rationale:

Specifying an explicit revision in coverage tags allows incrementing the revision when the implementation changes. Without this, OFT would always assign the default revision `0`.

Covers:

* `req~import.full-coverage-tag-format~2`

Needs: impl, utest

#### Full Coverage Tag Format Allows Specifying Name and Revision
`dsn~import.full-coverage-tag-with-name-and-revision~1`

OFT imports full coverage tags with optional name and revision:

    full-tag-with-name-and-revision =
        "[" *WSP covering-artifact-type "~" covering-name "~" covering-revision
        "->" covered-requirement-id "]"

    full-tag-with-name-and-revision-with-needed-coverage =
        "[" *WSP covering-artifact-type "~" xxx "~" revision *WSP
        "->" *WSP requirement-id *WSP
        ">>" *WSP artifact-type *WSP *("," *WSP artifact-type) "]"

Rationale:

Specifying an explicit name in coverage tags allows overriding the auto-generated name.

Covers:

* `req~import.full-coverage-tag-format~2`

Needs: impl, utest

#### Coverage Tag With Needed Coverage Generates Readable Names
`dsn~import.full-coverage-tag-with-needed-coverage-readable-names~1`

OFT generates readable names without hash code ID for tags with needed coverage.

Rationale:

When you need to cover these items it's important that the name is predictable and does not change e.g. when the file changes.

Covers:

* `req~import.full-coverage-tag-format~2`

Needs: impl, utest

#### Short Coverage Tag Format
`dsn~import.short-coverage-tag~1`

OFT imports coverage tags in the short tag format:

    short-tag = "[" "[" *WSP reference ":" *revision "]" "]"

During import of short tags OFT requires the following configuration:

* Path from which to import the tags
* Artifact type of the tags
* Artifact type of the covered specification item
* Name prefix of the covered specification item. The prefix is optional, default value: `project name "."`

Covers:

* `req~import.short-coverage-tag-format~2`

Needs: impl, utest

## User Interface

### CLI Command Selection
`dsn~cli.command-selection~1`

The CLI expects one of the following commands as first unnamed command line parameter:

    command = "trace" / "convert" / "help"

Covers:

* `req~cli.tracing.command~1`
* `req~cli.conversion.command~1`

Needs: impl, itest

### Common

#### CLI Help
`dsn~cli.help~1`

The CLI provides a help command and flags (`help`, `-h`, `--help`) that display a short help text.

Covers:

* [`req~cli.help~1`](system_requirements.md#cli-help)

Needs: impl, itest

#### CLI Version
`dsn~cli.version~1`

The CLI provides the current version of OpenFastTrace read from the resource file `version.properties` that is created during the build from the property `revision` in the core POM.

Rationale:

This makes the `revision` the single source of truth for the version of OpenFastTrace and avoids having to keep manually maintained copies of the version information.

Covers:

* [`req~cli.version~1`](system_requirements.md#cli-version)

Needs: impl, itest

#### Input File Selection
`dsn~cli.input-file-selection~1`

The CLI accepts the following two variants for defining input files:

* A list of files
* A list of directories

In both cases relative and absolute paths are accepted. "Relative" means in relation to the current working directory.

Covers:

* `req~cli.input-selection~1`

Needs: impl, itest

#### Input Directory Recursive Traversal
`dsn~input-directory-recursive-traversal~1`

The Importer reads all requirement input files from all input directories recursively.

Covers:

* `req~cli.input-directory-selection~1`

Needs: impl, itest

#### Default Input
`dsn~cli.default-input~1`

If the user does not specify any inputs as CLI parameters, the CLI uses the current working directory as default input.

Covers:

* `req~cli.default-input~1`

Needs: impl, itest

#### Newline Format
`dsn~newline-format~1`

The CLI accepts one of the following newline formats:

    new-line-format = "unix" / "windows"

Rationale:

When users work together in teams where the team members use different platforms, configuring the newline helps the team to set a common standard.

Covers:

* `req~cli.newline-format~1`

Needs: impl, itest

#### Default Newline Format
`dsn~cli.default-newline-format~1`

If the user does not specify the newline format as parameter, the exporter uses the native newline format of the platform OFT is executed on.

Covers:

* `req~cli.default-newline-format~1`

Needs: impl, itest

### Requirement Tracing

#### Tracing Output Format
`dsn~cli.tracing.output-format~1`

The CLI accepts one of the following requirement tracing report formats as parameter:

    report-formats = "plain"

Covers:

* `req~cli.tracing.output-format~1`

Needs: impl, itest

#### Default Tracing Output Format
`dsn~cli.tracing.default-format~1`

The CLI uses plain text as requirement tracing report format if none is given as a parameter.

Covers:

* `req~cli.tracing.default-output-format~1`

Needs: impl, utest

#### Tracing Exit Status
`dsn~cli.tracing.exit-status~1`

The return value of the OFT executable is:

* `0` tracing was successful
* `1` tracing ran successfully, but the tracing result is negative

Covers:

* `req~cli.tracing.exit-status~1`

Needs: impl, itest

### Requirement Format Conversion

#### Conversion Output Format
`dsn~cli.conversion.output-format~1`

The CLI accepts one of the following export formats as parameter:

    export-formats = "reqm2"

Covers:

* `req~cli.conversion.output-format~1`

Needs: impl, itest

#### Default Conversion Output Format
`dsn~cli.conversion.default-output-format~1`

The CLI uses ReqM2 as export format if none is given as a parameter.

Covers:

* `req~cli.conversion.default-output-format~1`

Needs: impl, itest, utest

### Listing Plugins
`dsn~cli.plugins.log~1`

The CLI logs available plugins in OFT at startup.

Covers:
- [req~plugins.log~1](system_requirements.md#logging-available-plugins)

Needs: impl

# Quality Requirements

See [Quality Requirements](design/quality_requirements.md).

# Design Decisions

## How do we Implement the Command Line Interpreter
`dsn~reflection-based-cli~1`

OFT got its own simple command line interpreter that uses reflection to feed the command line arguments to a receiver object.

Rationale:

One of the design goal of OFT is that it works without external runtime dependencies except for the Java Standard API. So taking an existing CLI was no option.
Using reflection allows the CLI user to implement the receiver as a POJO. No annotations are necessary.

Covers:

* `req~cli.tracing.command~1`
* `req~cli.conversion.command~1`

### Why is This Architecture Relevant?

Exchanging the CLI later takes considerable effort.

### Alternatives Considered

* No CLI (plain argument list) - not flexible enough
* External CLI - breaks design goal

## How do we Clean Imported Multi-line Text Elements
`dsn~cleaning-imported-multi-line-text-elements~1`

The `ImportEventListener`s do the following clean-up steps in multi-line text elements like the description:

* Trimming (removing leading and trailing spaces of the whole text -- no individual lines.)

Rationale:

This way we do cleanup in a central place and don't produce code duplication. Extra clean-up in the importers is still possible, but basics like trimming need to be handled in common code.

Needs: impl, utest

### Why is This Architecture Relevant?

Authors of importers need to be able to rely on these cleanups being done centrally, so that they don't have to implement them themselves.

### Alternatives Considered

Clean-up in every importer individually. That was the case up to and including OFT 3.7.1 which turned out to make the importer more complex than necessary.

# Bibliography

The following documents or are referenced in this specification.

[bib.srs]: system_requirements.md "OpenFastTrace System Requirement Specification"
[bib.abnf]: ftp://ftp.rfc-editor.org/in-notes/std/std68.txt "Augmented BNF for Syntax Specifications: ABNF"
[bib.arc42]: http://arc42.org

## Specifications

* [System Requirement Specification OpenFastTrace][bib.srs], Sebastian Bär
* [Augmented BNF for Syntax Specifications: ABNF][bib.abnf] , D. Crocker, P. Overell, January 2008

## Web Sites

* [arc42 - Ressources for software architects][bib.arc42], Dr. Gernot Starke, Dr. Peter Hruschka
