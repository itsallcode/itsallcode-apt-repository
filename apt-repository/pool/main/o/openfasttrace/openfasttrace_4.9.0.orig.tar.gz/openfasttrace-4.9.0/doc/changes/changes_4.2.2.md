# OpenFastTrace 4.2.2, released 2025-02-02

Code name: SystemVerilog file support

## Summary

In this release we added support for SystemVerilog files. 

### Dependency Updates

* `net.sourceforge.plantuml:plantuml:1.2026.0` → `1.2026.1`
* `nl.jqno.equalsverifier:equalsverifier:4.3` → `4.3.1`
* `org.junit.jupiter:junit-jupiter-api:6.0.1` → `6.1.0-M1`
* `org.junit.jupiter:junit-jupiter-engine:6.0.1` → `6.1.0-M1`
* `org.junit.platform:junit-jupiter-params:6.0.1` → `6.1.0-M1`

## Plugin Updates

Please note that plugin updates are only relevant if you want to build OFT. If you run OFT, no update is required.

* `org.codehaus.mojo:versions-maven-plugin:2.20.1` → `2.21.0`

## Bugfixes

* #471: Add tag importer support for SystemVerilog files
