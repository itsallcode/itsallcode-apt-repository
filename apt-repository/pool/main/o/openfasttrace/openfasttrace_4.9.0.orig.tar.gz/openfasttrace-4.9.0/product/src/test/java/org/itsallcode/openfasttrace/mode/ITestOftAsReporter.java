package org.itsallcode.openfasttrace.mode;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

import org.itsallcode.openfasttrace.api.FilterSettings;
import org.itsallcode.openfasttrace.api.ReportSettings;
import org.itsallcode.openfasttrace.api.core.*;
import org.itsallcode.openfasttrace.api.importer.ImportSettings;
import org.itsallcode.openfasttrace.api.report.ReportVerbosity;
import org.itsallcode.openfasttrace.core.Oft;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class ITestOftAsReporter extends AbstractOftTest
{
    private Oft oft;
    private Trace trace;

    @BeforeEach
    void beforeEach(@TempDir final Path tempDir)
    {
        prepareOutput(tempDir);
        final ImportSettings settings = ImportSettings.builder().addInputs(this.docDir).build();
        this.oft = Oft.create();
        final List<SpecificationItem> items = this.oft.importItems(settings);
        final List<LinkedSpecificationItem> linkedItems = this.oft.link(items);
        this.trace = this.oft.trace(linkedItems);
    }

    @Test
    void testTraceToFile() throws IOException
    {
        this.oft.reportToPath(this.trace, this.outputFile);
        assertStandardReportFileResult();
    }

    private void assertStandardReportFileResult() throws IOException
    {
        assertOutputFileExists(true);
        assertOutputFileContentStartsWith("ok - 5 total");
    }

    @Test
    void testTraceWithReportVerbosityMinimal() throws IOException
    {
        final ReportSettings settings = ReportSettings.builder().verbosity(ReportVerbosity.MINIMAL)
                .build();
        this.oft.reportToPath(this.trace, this.outputFile, settings);
        assertOutputFileExists(true);
        assertOutputFileContentStartsWith("ok");
    }

    @Test
    void testTraceMacNewlines() throws IOException
    {
        final ReportSettings settings = ReportSettings.builder() //
                .newline(Newline.OLDMAC) //
                .build();
        this.oft.reportToPath(this.trace, this.outputFile, settings);
        assertThat(Files.exists(this.outputFile), equalTo(true));
        assertThat("Has old Mac newlines", getOutputFileContent().contains(CARRIAGE_RETURN),
                equalTo(true));
        assertThat("Has no Unix newlines", getOutputFileContent().contains(NEWLINE),
                equalTo(false));
    }

    @Test
    void testTraceToStdOut()
    {
        this.oft.reportToStdOut(this.trace);
        assertStandardReportStdOutResult();
    }

    private void assertStandardReportStdOutResult()
    {
        assertStdOutStartsWith("ok - 5 total");
    }

    // [itest->dsn~filtering-by-artifact-types-during-import~1]
    @Test
    void testFilterAllowsAllAtrifactsButDsn()
    {
        final Set<String> artifactTypes = new HashSet<>(Arrays.asList("feat", "req"));
        assertThat("Number of items with type \"dsn\" in regular trace",
                countItemsOfArtifactTypeInTrace("dsn", this.trace), greaterThan(0L));
        final FilterSettings filterSettings = FilterSettings.builder()
                .artifactTypes(artifactTypes).build();
        final Trace filteredTrace = traceWithFilters(filterSettings);
        assertThat("Number of items with ignored type \"dsn\" in filtered trace",
                countItemsOfArtifactTypeInTrace("dsn", filteredTrace), equalTo(0L));
    }

    private Trace traceWithFilters(final FilterSettings filterSettings)
    {
        final ImportSettings importSettings = ImportSettings.builder().filter(filterSettings)
                .build();
        final List<SpecificationItem> filteredItems = this.oft.importItems(importSettings);
        final List<LinkedSpecificationItem> filteredSpecificationItems = this.oft
                .link(filteredItems);
        return this.oft.trace(filteredSpecificationItems);
    }

    private long countItemsOfArtifactTypeInTrace(final String artifactType, final Trace trace)
    {
        return trace.getItems().stream() //
                .filter(item -> item.getArtifactType().equals(artifactType)) //
                .count();
    }
}
