package org.itsallcode.openfasttrace.exporter.specobject;

import static java.util.Arrays.asList;
import static org.hamcrest.MatcherAssert.assertThat;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.List;

import javax.xml.stream.*;

import org.itsallcode.matcher.auto.AutoMatcher;
import org.itsallcode.openfasttrace.api.core.*;
import org.itsallcode.openfasttrace.api.importer.SpecificationListBuilder;
import org.itsallcode.openfasttrace.api.importer.input.InputFile;
import org.itsallcode.openfasttrace.importer.specobject.SpecobjectImporterFactory;
import org.itsallcode.openfasttrace.testutil.importer.input.StreamInput;
import org.itsallcode.openfasttrace.testutil.xml.IndentingXMLStreamWriter;
import org.junit.jupiter.api.Test;

class TestSpecobjectExportImport
{
    @Test
    void testExportImportSimpleSpecObjectWithMandatoryElements()
    {
        final SpecificationItem item = SpecificationItem.builder() //
                .id(SpecificationItemId.createId("foo", "bar", 1)) //
                .description("the description") //
                .location(location(4)) //
                .build();
        assertExportAndImport(item);
    }

    @Test
    void testExportImportSpecObjectWithOptionalElements()
    {
        final SpecificationItem item = SpecificationItem.builder() //
                .id(SpecificationItemId.createId("req", "me", 2)) //
                .title("My item title") //
                .status(ItemStatus.DRAFT) //
                .description("the description") //
                .rationale("the rationale") //
                .comment("the comment") //
                .addCoveredId("feat", "covered", 1) //
                .addDependOnId("req", "depend-on", 1) //
                .addNeedsArtifactType("impl") //
                .addTag("the tag") //
                .location(location(4)) //
                .build();
        assertExportAndImport(item);
    }

    @Test
    void testExportImportTwoSpecObjects()
    {
        final SpecificationItem itemA = SpecificationItem.builder() //
                .id(SpecificationItemId.createId("foo", "bar", 1)) //
                .status(ItemStatus.PROPOSED) //
                .description("the description") //
                .rationale("the rationale") //
                .comment("the comment") //
                .location(location(4)) //
                .build();
        final SpecificationItem itemB = SpecificationItem.builder() //
                .id(SpecificationItemId.createId("baz", "zoo", 2)) //
                .status(ItemStatus.REJECTED) //
                .description("another\ndescription") //
                .rationale("another\nrationale") //
                .comment("another\ncomment") //
                .location(location(5)) //
                .build();
        assertExportAndImport(itemA, itemB);
    }

    private org.itsallcode.openfasttrace.api.core.Location location(final int line)
    {
        return org.itsallcode.openfasttrace.api.core.Location.create("dummy.xml", line);
    }

    private void assertExportAndImport(final SpecificationItem... items)
    {
        final String exportedItems = exportToString(items);
        final List<SpecificationItem> importedItems = importItems(exportedItems);
        assertThat(importedItems, AutoMatcher.contains(items));
    }

    private List<SpecificationItem> importItems(final String exportedItems)
    {
        final InputFile input = StreamInput.forContent(Paths.get("dummy.xml"), exportedItems);
        final SpecificationListBuilder itemBuilder = SpecificationListBuilder.create();
        new SpecobjectImporterFactory().createImporter(input, itemBuilder).runImport();
        return itemBuilder.build();
    }

    private String exportToString(final SpecificationItem... items)
    {
        try (final ByteArrayOutputStream stream = new ByteArrayOutputStream())
        {
            final XMLOutputFactory outputFactory = XMLOutputFactory.newInstance();
            final XMLStreamWriter xmlWriter = outputFactory.createXMLStreamWriter(stream,
                    StandardCharsets.UTF_8.name());
            new SpecobjectExporter(asList(items).stream(),
                    new IndentingXMLStreamWriter(xmlWriter, " ", Newline.UNIX.toString()),
                    new OutputStreamWriter(stream), Newline.UNIX).runExport();
            return new String(stream.toByteArray(), StandardCharsets.UTF_8);
        }
        catch (IOException | XMLStreamException | FactoryConfigurationError e)
        {
            throw new AssertionError("Error exporting items", e);
        }
    }
}
