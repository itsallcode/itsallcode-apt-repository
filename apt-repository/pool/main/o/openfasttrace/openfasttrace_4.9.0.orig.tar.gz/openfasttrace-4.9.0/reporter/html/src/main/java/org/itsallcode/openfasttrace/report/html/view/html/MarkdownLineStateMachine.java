package org.itsallcode.openfasttrace.report.html.view.html;

import static org.itsallcode.openfasttrace.report.html.view.html.MarkdownLineState.*;

import java.util.ArrayList;
import java.util.List;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;

/**
 * A state machine for converting Markdown to HTML.
 */
public final class MarkdownLineStateMachine
{
    private static final int INCLUDE_EMPTY_STRINGS = -1;
    private static final String P_ANY = ".*";
    private static final String P_OL_LI = "^ {0,3}[0-9]+\\..*";
    private static final String P_UL_LI = "^ {0,3}[-+*].*";
    private static final String P_PRE = "^    .*";
    private static final String P_LIST_CONT = ".+";
    private static final String P_TERM = "^$";
    private static final Pattern ANY_NEWLINE = Pattern.compile("\n\r?|\r");
    private static final Pattern BULLET_POINT_PREFIX = Pattern.compile("^ {0,3}[-+*]");
    private final List<MarkdownLineTransition> transitions = new ArrayList<>();

    MarkdownLineStateMachine()
    {
        initializeTransitions();
    }

    // Duplicate strings help make this easier to understand.
    @SuppressWarnings("squid:S1192")
    private void initializeTransitions()
    {
        // @formatter:off
        t(START         , PREFORMATTED  , P_PRE      , ""          , "<pre>"   , trimPre());
        t(START         , UNORDERED_LIST, P_UL_LI    , ""          , "<ul><li>", trimBullet());
        t(START         , ORDERED_LIST  , P_OL_LI    , ""          , "<ol><li>", trimEnum());
        t(START         , PARAGRAPH     , P_ANY      , ""          , "<p>"     , String::trim);
        t(START         , TERMINATOR    , P_TERM     , ""          , ""        , empty());
        t(UNORDERED_LIST, UNORDERED_LIST, P_UL_LI    , "</li>"     , "<li>"    , trimBullet());
        t(UNORDERED_LIST, ORDERED_LIST  , P_UL_LI    , "</li></ul>", "<ol><li>", trimEnum());
        t(UNORDERED_LIST, UNORDERED_LIST, P_LIST_CONT, ""          , " "       , String::trim);
        t(UNORDERED_LIST, PREFORMATTED  , P_PRE      , "</li></ul>", "<pre>"   , trimPre());
        t(UNORDERED_LIST, TERMINATOR    , P_TERM     , "</li></ul>" , ""       , empty());
        t(UNORDERED_LIST, PARAGRAPH     , P_ANY      , "</li></ul>", "<p>"     , String::trim);
        t(ORDERED_LIST  , UNORDERED_LIST, P_UL_LI    , "</li></ol>", "<ul><li>", trimBullet());
        t(ORDERED_LIST  , ORDERED_LIST  , P_OL_LI    , "</li>"     , "<li>"    , trimEnum());
        t(ORDERED_LIST  , UNORDERED_LIST, P_LIST_CONT, ""          , " "       , String::trim);
        t(ORDERED_LIST  , PREFORMATTED  , P_PRE      , "</li></ol>", "<pre>"   , trimPre());
        t(ORDERED_LIST  , TERMINATOR    , P_TERM     , "</li></ol>", ""        , empty());
        t(ORDERED_LIST  , PARAGRAPH     , P_ANY      , "</li></ol>", "<p>"     , String::trim);
        t(PREFORMATTED  , PREFORMATTED  , P_PRE      , ""          , "\n"      , trimPre());
        t(PREFORMATTED  , UNORDERED_LIST, P_UL_LI    , "</pre>"    , "<ul><li>", trimBullet());
        t(PREFORMATTED  , ORDERED_LIST  , P_OL_LI    , "</pre>"    , "<ol><li>", trimEnum());
        t(PREFORMATTED  , TERMINATOR    , P_TERM     , "</pre>"    , ""        , empty());
        t(PREFORMATTED  , PARAGRAPH     , P_ANY      , "</pre>"    , "<p>"     , String::trim);
        t(TERMINATOR    , TERMINATOR    , P_TERM     , ""          , ""        , empty());
        t(TERMINATOR    , UNORDERED_LIST, P_UL_LI    , ""          , "<ul><li>", trimBullet());
        t(TERMINATOR    , ORDERED_LIST  , P_OL_LI    , ""          , "<ol><li>", trimEnum());
        t(TERMINATOR    , PREFORMATTED  , P_PRE      , ""          , "<pre>"   , trimPre());
        t(TERMINATOR    , PARAGRAPH     , P_ANY      , ""          , "<p>"     , String::trim);
        t(PARAGRAPH     , UNORDERED_LIST, P_UL_LI    , "</p>"      , "<ul><li>", trimBullet());
        t(PARAGRAPH     , ORDERED_LIST  , P_OL_LI    , "</p>"      , "<ol><li>", trimEnum());
        t(PARAGRAPH     , PREFORMATTED  , P_PRE      , "</p>"      , "<pre>"   , String::trim);
        t(PARAGRAPH     , TERMINATOR    , P_TERM     , "</p>"      , ""        , empty());
        t(PARAGRAPH     , PARAGRAPH     , P_ANY      , ""          , " "       , String::trim);
        // @formatter:on
    }

    private void t(final MarkdownLineState from, final MarkdownLineState to, final String pattern,
            final String postfix, final String prefix, final UnaryOperator<String> conversion)
    {
        this.transitions
                .add(new MarkdownLineTransition(from, to, pattern, prefix, postfix, conversion));
    }

    String run(final String input)
    {
        final StringBuilder builder = new StringBuilder();
        MarkdownLineState state = START;
        for (final String line : ANY_NEWLINE.split(input, INCLUDE_EMPTY_STRINGS))
        {
            for (final MarkdownLineTransition transition : this.transitions)
            {
                if (transition.getFrom() == state
                        && transition.getPattern().matcher(line).matches())
                {
                    builder.append(transition.getPostfix());
                    builder.append(transition.getPrefix());
                    builder.append(MarkdownSpanConverter
                            .convertLineContent(transition.getConversion().apply(line)));
                    state = transition.getTo();
                    break;
                }
            }
        }
        closeLastLineState(builder, state);
        return builder.toString();
    }

    private static void closeLastLineState(final StringBuilder builder, final MarkdownLineState state)
    {
        switch (state)
        {
        case PREFORMATTED:
            builder.append("</pre>");
            break;
        case UNORDERED_LIST:
            builder.append("</li></ul>");
            break;
        case ORDERED_LIST:
            builder.append("</li></ol>");
            break;
        case PARAGRAPH:
            builder.append("</p>");
            break;
        case TERMINATOR:
            break;
        default:
            throw new IllegalStateException(
                    "MarkdownLineStateMachine terminates with unknown end state");
        }
    }

    private static UnaryOperator<String> empty()
    {
        return s -> "";
    }

    private static UnaryOperator<String> trimEnum()
    {
        return s -> s.substring(s.indexOf('.') + 1).trim();
    }

    private static UnaryOperator<String> trimPre()
    {
        return s -> s.substring(4);
    }

    private static UnaryOperator<String> trimBullet()
    {
        return s -> BULLET_POINT_PREFIX.matcher(s).replaceFirst("").trim();
    }
}
