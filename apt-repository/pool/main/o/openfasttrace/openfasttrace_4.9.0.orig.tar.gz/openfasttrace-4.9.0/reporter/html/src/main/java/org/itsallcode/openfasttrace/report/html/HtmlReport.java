package org.itsallcode.openfasttrace.report.html;

import java.io.OutputStream;
import java.net.URL;
import java.util.List;

import org.itsallcode.openfasttrace.api.ReportSettings;
import org.itsallcode.openfasttrace.api.core.LinkedSpecificationItem;
import org.itsallcode.openfasttrace.api.core.Trace;
import org.itsallcode.openfasttrace.api.report.Reportable;
import org.itsallcode.openfasttrace.report.html.view.*;
import org.itsallcode.openfasttrace.report.html.view.html.HtmlViewFactory;

import static java.util.Comparator.comparing;

/**
 * An HTML report.
 */
public class HtmlReport implements Reportable
{
    private static final String REPORT_CSS_FILE = "/css/report.css";
    private final Trace trace;
    private final ReportSettings settings;

    /**
     * Create a new instance of an {@link HtmlReport}
     * 
     * @param trace
     *            trace to be reported on
     * @param settings
     *            report settings to use
     */
    public HtmlReport(final Trace trace, final ReportSettings settings)
    {
        this.trace = trace;
        this.settings = settings;
    }

    /**
     * Get the URL to the CSS stylesheet that is used to lay out the HTML Report
     * 
     * @return the URL of the CSS stylesheet
     */
    public static URL getCssUrl()
    {
        return HtmlReport.class.getResource(REPORT_CSS_FILE);
    }

    @Override
    public void renderToStream(final OutputStream outputStream)
    {
        final ViewFactory factory = HtmlViewFactory.create(outputStream, getCssUrl(),
                settings.getDetailsSectionDisplay());
        final ViewableContainer view = factory.createView("",
                "Specification items by artifact type");
        final ViewableContainer details = createDetails(factory);
        final ViewableContainer summary = createSummary(details, factory);
        view.add(details);
        view.add(summary);
        view.render();
    }

    private ViewableContainer createDetails(final ViewFactory factory)
    {
        final ViewableContainer details = factory.createReportDetails();
        final List<LinkedSpecificationItem> items = getSortedItems();
        addSectionedItems(factory, details, items);
        return details;
    }

    private List<LinkedSpecificationItem> getSortedItems()
    {
        return this.trace.getItems()
                .stream()
                .sorted(comparing(LinkedSpecificationItem::getArtifactType)
                        .thenComparing(LinkedSpecificationItem::getTitleWithFallback))
                .toList();
    }

    private static void addSectionedItems(final ViewFactory factory, final ViewableContainer view,
            final List<LinkedSpecificationItem> items)
    {
        String artifactType = "\0";
        ViewableContainer section = factory.createSection(artifactType, artifactType);
        for (final LinkedSpecificationItem item : items)
        {
            final String currentArtifactType = item.getArtifactType();
            if (!artifactType.equals(currentArtifactType))
            {
                artifactType = currentArtifactType;
                section = factory.createSection(artifactType, artifactType);
                view.add(section);
            }
            final Viewable itemView = factory.createSpecificationItem(item);
            section.add(itemView);
        }
    }

    private ViewableContainer createSummary(final ViewableContainer view,
            final ViewFactory factory)
    {
        final ViewableContainer summary = factory.createReportSummary();
        summary.add(factory.createTraceSummary(this.trace));
        summary.add(factory.createTableOfContents(view));
        return summary;
    }
}
