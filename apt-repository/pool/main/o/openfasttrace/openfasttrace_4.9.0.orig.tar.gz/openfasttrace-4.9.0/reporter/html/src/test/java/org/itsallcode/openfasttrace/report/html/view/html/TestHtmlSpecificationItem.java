package org.itsallcode.openfasttrace.report.html.view.html;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.itsallcode.openfasttrace.report.html.view.html.CharacterConstants.CHECK_MARK;
import static org.itsallcode.openfasttrace.report.html.view.html.CharacterConstants.CROSS_MARK;
import static org.itsallcode.openfasttrace.report.html.view.html.CharacterConstants.TRANSITIVE_FAILURE_MARK;
import static org.itsallcode.openfasttrace.testutil.core.SampleArtifactTypes.IMPL;
import static org.itsallcode.openfasttrace.testutil.core.SampleArtifactTypes.ITEST;
import static org.itsallcode.openfasttrace.testutil.core.SampleArtifactTypes.UTEST;
import static org.mockito.Mockito.lenient;

import org.hamcrest.Matcher;
import org.itsallcode.openfasttrace.api.DetailsSectionDisplay;
import org.itsallcode.openfasttrace.api.core.*;
import org.itsallcode.openfasttrace.report.html.HtmlReport;
import org.itsallcode.openfasttrace.report.html.view.Viewable;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.itsallcode.openfasttrace.testutil.core.ItemBuilderFactory.itemWithId;

@ExtendWith(MockitoExtension.class)
class TestHtmlSpecificationItem extends AbstractTestHtmlRenderer
{
    private static final SpecificationItemId ITEM_A_ID = SpecificationItemId
            .parseId("dsn~name-a~1");
    private static final SpecificationItemId ITEM_B_ID = SpecificationItemId
            .parseId("impl~name-b~1");
    private static final SpecificationItemId ITEM_C_ID = SpecificationItemId
            .parseId("utest~name-c~1");

    @Mock
    private LinkedSpecificationItem itemMockB;
    @Mock
    private LinkedSpecificationItem itemMockC;

    @Mock
    private SpecificationItem itemMock;

    @Override
    @BeforeEach
    public void prepareEachTest()
    {
        super.prepareEachTest();
        lenient().when(this.itemMockB.getId()).thenReturn(ITEM_B_ID);
        lenient().when(this.itemMockB.getItem()).thenReturn(itemMock);
        lenient().when(this.itemMockC.getId()).thenReturn(ITEM_C_ID);
        lenient().when(this.itemMockC.getItem()).thenReturn(itemMock);
    }

    @Test
    void testRenderMinimalItem()
    {
        final SpecificationItem item = itemWithId(ITEM_A_ID) //
                .title("Item A title") //
                .description("Single line description") //
                .build();
        renderItemOnIndentationLevel(item, 1);
        assertOutputLines( //
                "  <section class=\"sitem\" id=\"dsn~name-a~1\">", //
                "    <details>", //
                "      <summary title=\"dsn~name-a~1\">" + CHECK_MARK
                        + " <b>Item A title</b><small>, rev. 1, dsn</small></summary>", //
                "      <p class=\"id\">" + ITEM_A_ID + "</p>", //
                "      <p>Single line description</p>", //
                "    </details>", //
                "  </section>", //
                "");
    }

    // [utest->dsn~reporting.html.details-display~1]
    @ParameterizedTest
    @CsvSource(nullValues = "NULL", value =
    { "NULL, <details>", "COLLAPSE, <details>", "EXPAND, <details open>" })
    void testRenderDetailsDefaultValue(final DetailsSectionDisplay displayStatus, final String expectedDetailsElement)
    {
        this.factory = HtmlViewFactory.create(this.outputStream, HtmlReport.getCssUrl(),
                displayStatus);
        final SpecificationItem item = itemWithId(ITEM_A_ID) //
                .title("Item A title") //
                .description("Single line description") //
                .build();
        renderItemOnIndentationLevel(item, 1);
        assertThat(this.outputStream.toString(), containsString(expectedDetailsElement));
    }

    @Test
    void testRenderMultiLineItem()
    {
        final SpecificationItem item = itemWithId(ITEM_B_ID) //
                .title("Item B title") //
                .description("Description A\n\nDescription B") //
                .rationale("Rationale A\n\nRationale B") //
                .comment("Comment A\nComment B") //
                .build();
        renderItemOnIndentationLevel(item, 0);
        assertOutputLines( //
                "<section class=\"sitem\" id=\"impl~name-b~1\">", //
                "  <details>", //
                "    <summary title=\"impl~name-b~1\">" + CHECK_MARK
                        + " <b>Item B title</b><small>, rev. 1, impl</small></summary>", //
                "    <p class=\"id\">" + ITEM_B_ID + "</p>", //
                "    <p>Description A</p><p>Description B</p>", //
                "    <h6>Rationale:</h6>", //
                "    <p>Rationale A</p><p>Rationale B</p>", //
                "    <h6>Comment:</h6>", //
                "    <p>Comment A Comment B</p>", //
                "  </details>", //
                "</section>", //
                "");
    }

    protected void renderItemOnIndentationLevel(final SpecificationItem item,
            final int indentationLevel)
    {
        final LinkedSpecificationItem linkedItem = new LinkedSpecificationItem(item);
        final Viewable view = this.factory.createSpecificationItem(linkedItem);
        view.render(indentationLevel);
    }

    @Test
    // [utest->dsn~reporting.html.transitive-defect-mark~1]
    void testRenderTransitiveDefectMark()
    {
        final SpecificationItem item = itemWithId(ITEM_A_ID) //
                .addNeedsArtifactType(IMPL) //
                .build();
        final LinkedSpecificationItem linkedItem = new LinkedSpecificationItem(item);

        // Sub item provides IMPL but needs UTEST (and is not covered) -> defect
        final SpecificationItem subItem = itemWithId(ITEM_B_ID) //
                .addNeedsArtifactType(UTEST) //
                .build();
        final LinkedSpecificationItem linkedSubItem = new LinkedSpecificationItem(subItem);

        linkedItem.addLinkToItemWithStatus(linkedSubItem, LinkStatus.COVERED_SHALLOW);

        final Viewable view = this.factory.createSpecificationItem(linkedItem);
        view.render(0);
        assertThat(this.outputStream.toString(), containsString(TRANSITIVE_FAILURE_MARK));
    }

    @Test
    void testRenderNeeds()
    {
        final SpecificationItem item = itemWithId(ITEM_A_ID) //
                .addNeedsArtifactType(IMPL) //
                .addNeedsArtifactType(ITEST) //
                .addNeedsArtifactType(UTEST) //
                .build();
        final LinkedSpecificationItem linkedItem = new LinkedSpecificationItem(item);
        final Viewable view = this.factory.createSpecificationItem(linkedItem);
        view.render(0);
        assertOutputLines( //
                "<section class=\"sitem\" id=\"dsn~name-a~1\">", //
                "  <details>", //
                "    <summary title=\"dsn~name-a~1\">" + CROSS_MARK
                        + " <b>name-a</b><small>, rev. 1, dsn</small></summary>", //
                "    <p class=\"id\">" + ITEM_A_ID + "</p>", //
                "    <h6>Needs: <ins>impl</ins>, <ins>itest</ins>, <ins>utest</ins></h6>", //
                "  </details>", //
                "</section>", //
                "");
    }

    @Test
    void testRenderIncomingLinks()
    {
        final SpecificationItem item = itemWithId(ITEM_A_ID) //
                .build();
        final LinkedSpecificationItem linkedItem = new LinkedSpecificationItem(item);
        linkedItem.addLinkToItemWithStatus(this.itemMockB, LinkStatus.COVERED_SHALLOW);
        linkedItem.addLinkToItemWithStatus(this.itemMockC, LinkStatus.COVERED_UNWANTED);
        final Viewable view = this.factory.createSpecificationItem(linkedItem);
        view.render(0);
        assertOutputLines( //
                "<section class=\"sitem\" id=\"dsn~name-a~1\">", //
                "  <details>", //
                "    <summary title=\"dsn~name-a~1\">" + CROSS_MARK
                        + " <b>name-a</b><small>, rev. 1, dsn</small></summary>", //
                "    <p class=\"id\">" + ITEM_A_ID + "</p>", //
                "    <div class=\"in\">", //
                "      <h6>In: 2</h6>", //
                "      <ul>", //
                "        <li><a href=\"#" + ITEM_B_ID + "\">" + ITEM_B_ID + "</a></li>", //
                "        <li><a href=\"#" + ITEM_C_ID + "\">" + ITEM_C_ID
                        + "</a> <em>(unwanted coverage)</em></li>", //
                "      </ul>", //
                "    </div>", //
                "  </details>", //
                "</section>", //
                "");
    }

    @Test
    void testRenderOutgoingLinks()
    {
        final SpecificationItem item = itemWithId(ITEM_A_ID) //
                .build();
        final LinkedSpecificationItem linkedItem = new LinkedSpecificationItem(item);
        linkedItem.addLinkToItemWithStatus(this.itemMockB, LinkStatus.COVERS);
        linkedItem.addLinkToItemWithStatus(this.itemMockC, LinkStatus.UNWANTED);
        final Viewable view = this.factory.createSpecificationItem(linkedItem);
        view.render(0);
        assertOutputLines( //
                "<section class=\"sitem\" id=\"dsn~name-a~1\">", //
                "  <details>", //
                "    <summary title=\"dsn~name-a~1\">" + CROSS_MARK
                        + " <b>name-a</b><small>, rev. 1, dsn</small></summary>", //
                "    <p class=\"id\">" + ITEM_A_ID + "</p>", //
                "    <div class=\"out\">", //
                "      <h6>Out: 2</h6>", //
                "      <ul>", //
                "        <li><a href=\"#" + ITEM_B_ID + "\">" + ITEM_B_ID + "</a></li>", //
                "        <li><a href=\"#" + ITEM_C_ID + "\">" + ITEM_C_ID
                        + "</a> <em>(unwanted)</em></li>", //
                "      </ul>", //
                "    </div>", //
                "  </details>", //
                "</section>", //
                "");
    }

    @Test
    void testRenderOrigin()
    {
        final Location location = Location.create("foo/bar", 13);
        final SpecificationItem item = itemWithId(ITEM_A_ID) //
                .location(location) //
                .build();
        final LinkedSpecificationItem linkedItem = new LinkedSpecificationItem(item);
        final SpecificationItem subItem = itemWithId(ITEM_B_ID)
                .location(Location.create("http://example.org/foo.txt", 3)).build();
        final LinkedSpecificationItem linkedSubItem = new LinkedSpecificationItem(subItem);
        linkedItem.addLinkToItemWithStatus(linkedSubItem, LinkStatus.COVERED_SHALLOW);
        final Viewable view = this.factory.createSpecificationItem(linkedItem);
        view.render(0);
        assertOutputLines("<section class=\"sitem\" id=\"dsn~name-a~1\">", //
                "  <details>", //
                "    <summary title=\"dsn~name-a~1\">" + CHECK_MARK
                        + " <b>name-a</b><small>, rev. 1, dsn</small></summary>", //
                "    <p class=\"id\">" + ITEM_A_ID + "</p>", //
                "    <p class=\"origin\">foo/bar:13</p>", //
                "    <div class=\"in\">", //
                "      <h6>In: 1</h6>", //
                "      <ul>", //
                "        <li><a href=\"#" + ITEM_B_ID + "\">" + ITEM_B_ID
                        + "</a> <span class=\"origin\"><a href=\"http://example.org/foo.txt\">http://example.org/foo.txt</a>:3</span></li>",
                //
                "      </ul>", //
                "    </div>", //
                "  </details>", //
                "</section>", //
                "");
    }

    // [utest->dsn~reporting.html.escape-html~1]
    @Test
    void testRenderEscapesHtmlElementsInTitle()
    {
        assertRender(defaultItem().title("Title<tag>"),
                allOf(containsString("Title&lt;tag&gt;"), not(containsString("<tag>"))));
    }

    // [utest->dsn~reporting.html.escape-html~1]
    @Test
    void testRenderEscapesHtmlElementsInDescription()
    {
        assertRender(defaultItem().description("Description<tag>"),
                allOf(containsString("Description&lt;tag&gt;"), not(containsString("<tag>"))));
    }

    // [utest->dsn~reporting.html.escape-html~1]
    @Test
    void testRenderEscapesHtmlElementsInComment()
    {
        assertRender(defaultItem().comment("Comment<tag>"),
                allOf(containsString("Comment&lt;tag&gt;"), not(containsString("<tag>"))));
    }

    // [utest->dsn~reporting.html.escape-html~1]
    @Test
    void testRenderEscapesHtmlElementsInRationale()
    {
        assertRender(defaultItem().rationale("Rationale<tag>"),
                allOf(containsString("Rationale&lt;tag&gt;"), not(containsString("<tag>"))));
    }

    private SpecificationItem.Builder defaultItem()
    {
        return itemWithId(ITEM_A_ID);
    }

    private void assertRender(final SpecificationItem.Builder itemBuilder, final Matcher<String> matcher)
    {
        renderItemOnIndentationLevel(itemBuilder.build(), 0);
        assertOutput(matcher);
    }
}
