package org.itsallcode.openfasttrace.core.serviceloader;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.itsallcode.openfasttrace.api.ReportSettings;
import org.itsallcode.openfasttrace.api.core.Trace;
import org.itsallcode.openfasttrace.api.report.ReportException;
import org.itsallcode.openfasttrace.api.report.ReporterFactory;
import org.itsallcode.openfasttrace.core.Oft;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.opentest4j.TestAbortedException;

/**
 * Test for {@link ServiceLoaderFactory} from module {@code core}. This test
 * must be located in module {@code product} (which includes all plugin modules)
 * so that it can access all plugin services.
 */
// [itest->dsn~plugins.loading~1]
class ServiceLoaderFactoryIT
{
    @TempDir
    Path tempDir;

    @Test
    void loadServiceFromWrongJar() throws IOException
    {
        preparePlugin(Path.of("../reporter/plaintext/target"),
                Pattern.compile("openfasttrace-reporter-plaintext-\\d+\\.\\d+\\.\\d+-javadoc.jar"));
        try (Loader<ReporterFactory> loader = createLoader())
        {
            final List<ReporterFactory> service = loader.load().toList();
            assertThat(service, empty());
        }
    }

    private Loader<ReporterFactory> createLoader()
    {
        return new ServiceLoaderFactory(ServiceLoaderConfig.builder()
                .pluginsDirectory(tempDir)
                .searchCurrentClasspath(false)
                .build()).createLoader(ReporterFactory.class);
    }

    // [itest->dsn~plugins.loading.configuration~1]
    @Test
    void loadMultiplePluginsFromOneConfiguredPlugin() throws IOException
    {
        final Path plaintextJar = findPluginJar(Path.of("../reporter/plaintext/target"),
                Pattern.compile("openfasttrace-reporter-plaintext-\\d+\\.\\d+\\.\\d+\\.jar"));
        final Path htmlJar = findPluginJar(Path.of("../reporter/html/target"),
                Pattern.compile("openfasttrace-reporter-html-\\d+\\.\\d+\\.\\d+\\.jar"));
        final ServiceLoaderConfig config = ServiceLoaderConfig.builder()
                .pluginsDirectory(tempDir)
                .searchCurrentClasspath(false)
                .addPlugin(Plugin.of("reporters", plaintextJar, htmlJar))
                .build();
        try (Loader<ReporterFactory> loader = new ServiceLoaderFactory(config).createLoader(ReporterFactory.class))
        {
            final List<ReporterFactory> services = loader.load().toList();
            final List<String> serviceClassNames = services.stream()
                    .map(service -> service.getClass().getName())
                    .toList();
            assertAll(
                    () -> assertThat(services, hasSize(2)),
                    () -> assertThat(serviceClassNames, hasItem(
                            "org.itsallcode.openfasttrace.report.plaintext.PlaintextReporterFactory")),
                    () -> assertThat(serviceClassNames, hasItem(
                            "org.itsallcode.openfasttrace.report.html.HtmlReporterFactory")));
        }
    }

    private Path findPluginJar(final Path targetDir, final Pattern filePattern) throws IOException
    {
        return findMatchingFile(targetDir, filePattern)
                .orElseThrow(() -> new AssertionError(
                        "Did not find file matching '" + filePattern + "' in '" + targetDir
                                + "'. Ensure the module was built with 'mvn package'."));
    }

    @Test
    void loadServiceFromJar() throws IOException
    {
        preparePlugin(Path.of("../reporter/plaintext/target"),
                Pattern.compile("openfasttrace-reporter-plaintext-\\d+\\.\\d+\\.\\d+\\.jar"));
        try (Loader<ReporterFactory> loader = createLoader())
        {
            final List<ReporterFactory> services = loader.load().toList();
            assertThat(services, hasSize(1));
            final ReporterFactory service = services.get(0);
            final ClassLoader pluginClassLoader = service.getClass().getClassLoader();
            assertAll(
                    () -> assertThat(service.getClass().getName(),
                            equalTo("org.itsallcode.openfasttrace.report.plaintext.PlaintextReporterFactory")),
                    () -> assertThat(pluginClassLoader.getName(),
                            startsWith("JarClassLoader-openfasttrace-reporter-plaintext")),
                    () -> assertThat(pluginClassLoader,
                            not(sameInstance(Thread.currentThread().getContextClassLoader()))));
        }
    }

    // [itest->dsn~plugins.loading.configuration~1]
    @Test
    void configuredPluginLoadedThroughBuilder() throws IOException
    {
        final Path plaintextJar = findPluginJar(Path.of("../reporter/plaintext/target"),
                Pattern.compile("openfasttrace-reporter-plaintext-\\d+\\.\\d+\\.\\d+\\.jar"));
        final Trace emptyTrace = Trace.builder().items(List.of()).defectItems(List.of()).build();
        // Control: without a configured plugin the built-in "plain" reporter is found and succeeds
        final Path controlReport = tempDir.resolve("control.txt");
        Oft.create().reportToPath(emptyTrace, controlReport);
        assertThat(Files.readString(controlReport), startsWith("ok - 0 total"));

        // Configure same reporter as plugin, loading it a second time.
        // With two plugins for the "plain" format fails.
        final Oft oft = Oft.builder().addPlugin("plaintext", plaintextJar).build();
        final Path plainReport = tempDir.resolve("plain.txt");
        final ReportException exception = assertThrows(ReportException.class,
                () -> oft.reportToPath(emptyTrace, plainReport));
        assertThat(exception.getMessage(),
                equalTo("Found more than one matching reporter for output format 'plain'"));

        // Adding plugin does not remove other reporters: html reporter is still available.
        final Path htmlReport = tempDir.resolve("report.html");
        oft.reportToPath(emptyTrace, htmlReport, ReportSettings.builder().outputFormat("html").build());
        assertThat(Files.readString(htmlReport), startsWith("<!DOCTYPE html>"));
    }

    private void preparePlugin(final Path targetDir, final Pattern filePattern) throws TestAbortedException, IOException
    {
        final Path jar = findMatchingFile(targetDir, filePattern)
                .orElseThrow(() -> new AssertionError(
                        "Did not file matching '" + filePattern + "' in '" + targetDir
                                + "'. Ensure the module was built with 'mvn package'."));
        preparePlugin(jar);
    }

    private Optional<Path> findMatchingFile(final Path dir, final Pattern filePattern) throws IOException
    {
        try (final Stream<Path> files = Files.list(dir))
        {
            return files.filter(file -> filePattern.matcher(file.getFileName().toString()).matches())
                    .findFirst();
        }
    }

    private void preparePlugin(final Path pluginJar) throws IOException
    {
        final Path pluginDir = tempDir.resolve("plugin");
        Files.createDirectories(pluginDir);
        Files.copy(pluginJar, pluginDir.resolve(pluginJar.getFileName()));
    }
}
