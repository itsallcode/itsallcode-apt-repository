package org.itsallcode.openfasttrace.importer.markdown;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.is;
import static org.itsallcode.matcher.auto.AutoMatcher.contains;
import static org.itsallcode.openfasttrace.api.core.SpecificationItemId.createId;
import static org.itsallcode.openfasttrace.testutil.core.ItemBuilderFactory.item;
import static org.junit.jupiter.api.Assertions.assertAll;

import java.nio.file.Path;
import java.util.List;

import org.itsallcode.openfasttrace.api.core.*;
import org.itsallcode.openfasttrace.api.importer.*;
import org.itsallcode.openfasttrace.testutil.importer.ImportAssertions;
import org.itsallcode.openfasttrace.testutil.importer.lightweightmarkup.AbstractLightWeightMarkupImporterTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

class TestMarkdownMarkupImporter extends AbstractLightWeightMarkupImporterTest
{
    private static final String FULL_COVERAGE_TAG = "[doc" + "->req~guide~1]";
    private static final ImporterFactory importerFactory = createImporterFactory();

    TestMarkdownMarkupImporter()
    {
        super(0);
    }

    @Override
    protected ImporterFactory getImporterFactory()
    {
        return importerFactory;
    }

    private static ImporterFactory createImporterFactory()
    {
        final MarkdownImporterFactory factory = new MarkdownImporterFactory();
        factory.init(new ImporterContext(ImportSettings.createDefault()));
        return factory;
    }

    // [utest->dsn~markdown.comment-coverage-tags~1]
    @Test
    void testImportsCoverageTagFromStandaloneHtmlComment()
    {
        assertImport("guide.md", """
                # Guide
                <!-- %s -->
                req~ordinary~1
                """.formatted(FULL_COVERAGE_TAG), contains(
                item().id("doc", "guide-1257333065", 0)
                        .addCoveredId("req", "guide", 1)
                        .location("guide.md", 2).build(),
                item().id("req", "ordinary", 1).location("guide.md", 3).build()));
    }

    // [utest->dsn~markdown.comment-coverage-tags~1]
    @ParameterizedTest
    @ValueSource(strings =
    { FULL_COVERAGE_TAG,
            "before <!-- " + FULL_COVERAGE_TAG + " -->",
            "<!-- " + FULL_COVERAGE_TAG + " --> after",
            "<!-- " + FULL_COVERAGE_TAG,
            FULL_COVERAGE_TAG + " -->" })
    void testIgnoresCoverageTagsOutsideStandaloneHtmlComments(final String line)
    {
        assertImport("guide.md", line, emptyIterable());
    }

    // [utest->dsn~located-specification-item-id-text-ranges~1]
    @Test
    void testImportsLocatedDeclarationCoverageAndDependencyIds()
    {
        final SpecificationItem item = importText("""
                req~subject~1
                Covers:
                * req~covered~2
                Depends:
                * req~dependency~3
                """).get(0);

        assertAll(
                () -> assertThat(item.getLocatedId().getRange(), is(range(0, 0, 13))),
                () -> assertThat(item.getLocatedCoveredIds().get(0).getRange(), is(range(2, 2, 15))),
                () -> assertThat(item.getLocatedDependOnIds().get(0).getRange(), is(range(4, 2, 18))));
    }

    private static List<SpecificationItem> importText(final String source)
    {
        return ImportAssertions.runImporterOnText(Path.of("located.md"), source, importerFactory);
    }

    private static SourceRange range(final int line, final int start, final int end)
    {
        return new SourceRange(new SourcePosition(line, start), new SourcePosition(line, end));
    }

    protected String formatTitle(final String title, final int level)
    {
        return "#".repeat(level) + " " + title;
    }

    // [utest -> dsn~md.specification-item-title~1]
    @Test
    void testMarkdownTitleBeforeRequirementIdIsRequirementTitle()
    {
        assertImport("titles.md",
                """
                        # The title
                        the~id~1
                        """,
                contains(item()
                        .id("the", "id", 1)
                        .title("The title")
                        .location("titles.md", 2)
                        .build()));
    }

    // [utest -> dsn~md.specification-item-title~1]
    @Test
    void testMarkdownTitleDetectedAfterAnotherTitle()
    {
        assertImport("more_titles.md",
                """
                        # 1st level title

                        # 2nd level title

                        the~id~1
                        """,
                contains(item()
                        .title("2nd level title")
                        .id("the", "id", 1)
                        .location("more_titles.md", 5)
                        .build()));
    }

    // [utest->dsn~md.specification-item-title~1]
    @Test
    void testFindTitleAfterTitle()
    {
        assertImport("x", """
                ## This title should be ignored

                ### Title
                `a~b~1
                """,
                contains(item()
                        .id(SpecificationItemId.parseId("a~b~1"))
                        .title("Title").location("x", 4)
                        .build()));
    }

    @ParameterizedTest
    @ValueSource(strings =
    { "---------------------------------", "---", "===", "======", "--- ",
            "=== ", "---\t" })
    void testRecognizeItemTitleWithUnderlines(final String underline)
    {
        assertImport("file name", """
                This is a title with an underline
                %s
                `extra~support-underlined-headers~1`
                Body text.
                """.formatted(underline),
                contains(item()
                        .id(SpecificationItemId.createId("extra", "support-underlined-headers",
                                1))
                        .title("This is a title with an underline")
                        .description("Body text.")
                        .location("file name", 3)
                        .build()));
    }

    @ValueSource(strings = { "---------------------------------", "---", "===", "======",
            "================================================",
            "--- ", "=== ", "---\t"
    })
    @ParameterizedTest
    void testRecognizeItemTitleWithUnderlinesAfterAnotherTitle(final String underline)
    {
        assertImport("y", """
                # This must be ignored.
                This is a title with an underline
                %s
                `extra~support-underlined-headers~1`
                Body text.
                """.formatted(underline),
                contains(item()
                        .id(SpecificationItemId.createId("extra", "support-underlined-headers",
                                1))
                        .title("This is a title with an underline")
                        .description("Body text.")
                        .location("y", 4)
                        .build()));
    }

    @Test
    void testLessThenThreeUnderliningCharactersAreNotDetectedAsTitleUnderlines()
    {
        assertImport("z", """
                This is not a title since the underline is too short
                --
                req~too-short~111
                """,
                contains(item()
                        .id(SpecificationItemId.createId("req", "too-short", 111))
                        .location("z", 3)
                        .build()));
    }

    @ParameterizedTest
    @CsvSource(
    {
            "```,```",
            "``` ,``` ",
            "``` ,```",
            "````, ````",
            " ```, ```",
            "  ```,  ```",
            "   ```,   ```",
            "```java, ```",
            "```java , ``` ",
            "~~~, ~~~",
            "~~~java, ~~~",
            "  ~~~~java,  ~~~~ "
    })
    void testWhenInsideMarkdownCodeBlockThenNoSpecificationItemMustBeDetected(final String startMarker,
            final String endMarker)
    {
        assertImport("file_with_code_block.md", """
                %s
                This is a code block, the following requirement must be ignored.

                req~example~1
                %s
                """.formatted(startMarker, endMarker),
                emptyIterable());
    }

    @Test
    void testWhenCodeBlockDirectlyFollowsTitleThenFollowingSpecificationItemMustBeDetected()
    {
        assertImport("code_block_after_title.md", """
                ## A diagram before any requirement

                ```mermaid
                graph TD
                  A --> B
                ```

                `req~example~1`

                `req~example~2`
                """,
                contains(
                        item()
                                .id(SpecificationItemId.parseId("req~example~1"))
                                .location("code_block_after_title.md", 8)
                                .build(),
                        item()
                                .id(SpecificationItemId.parseId("req~example~2"))
                                .location("code_block_after_title.md", 10)
                                .build()));
    }

    @ParameterizedTest
    @CsvSource(
    {
            "`,`",
            "``,``",
            " ``', ``",
            "`` ,`` ",
            "``java,``",
            "~~,~~",
    })
    void testWhenNotInsideMarkdownCodeBlockThenSpecificationItemMustBeDetected(final String startMarker,
            final String endMarker)
    {
        assertImport("file_without_code_block.md", """
                %s
                This is not a code block, the following requirement must be detected.

                req~example~1
                %s
                """.formatted(startMarker, endMarker),
                contains(item()
                        .id(SpecificationItemId.parseId("req~example~1"))
                        .location("file_without_code_block.md", 4)
                        // End marker looks like part of the description in this
                        // case.
                        .description(endMarker)
                        .build()));
    }

    @Test
    void testWhenCodeBlockIsInsideCommentSectionThenItIsImportedAsPartOfComment()
    {
        assertImport("file_with_code_block_in_comment.md", """
                req~comment_with_code_block~1
                Comment:

                ```
                This is a code block inside a comment.
                ```
                """,
                contains(item()
                        .id(SpecificationItemId.createId("req", "comment_with_code_block", 1))
                        .comment("```" + System.lineSeparator() + "This is a code block inside a comment."
                                + System.lineSeparator() + "```")
                        .location("file_with_code_block_in_comment.md", 1)
                        .build()));
    }

    // [utest -> dsn~disabling-oft-parsing-for-parts-of-a-markup-file~1]
    @Test
    void testDisablingMarkdownParsingForATextBlock()
    {
        assertImport("disable_parsing.md", """
                `req~stop-parsing~1`

                The next part must not be parsed:

                <!-- oft:off -->
                `req~do-not-parse-me~2`

                Invisible.

                Needs: utest
                <!-- oft:on -->

                Needs: impl
                """,
                contains(item()
                        .id(createId("req", "stop-parsing", 1))
                        .description("The next part must not be parsed:")
                        .addNeedsArtifactType("impl")
                        .location("disable_parsing.md", 1)
                        .build()));
    }

    // [utest->dsn~md.tags-format~1]
    @Test
    void testSingleLineTagsFormat()
    {
        assertImport("tags_single.md", """
                req~single-line-tags~1
                Tags: feature_1, Release_2_0, 42_tag
                """, contains(item()
                .id("req", "single-line-tags", 1)
                .addTag("feature_1")
                .addTag("Release_2_0")
                .addTag("42_tag")
                .location("tags_single.md", 1)
                .build()));
    }

    // [utest->dsn~md.tags-format~1]
    @Test
    void testSingleLineTagsMalformedMixedList()
    {
        assertImport("tags_single_mixed.md", """
                req~single-mixed-tags~1
                Tags: valid_1, _invalid, valid_2, -bad, valid_3
                """, contains(item()
                .id("req", "single-mixed-tags", 1)
                .addTag("valid_1")
                .addTag("valid_2")
                .addTag("valid_3")
                .location("tags_single_mixed.md", 1)
                .build()));
    }

    // [utest->dsn~md.tags-format~1]
    @Test
    void testSingleLineTagsAllMalformedProducesEmptyTags()
    {
        assertImport("tags_single_invalid.md", """
                req~single-invalid-tags~1
                Tags: _invalid, -bad, täg
                """, contains(item()
                .id("req", "single-invalid-tags", 1)
                .location("tags_single_invalid.md", 1)
                .build()));
    }

    // [utest->dsn~md.tags-format~1]
    @Test
    void testBulletedTagsFormat()
    {
        assertImport("tags_list.md", """
                req~bulleted-tags~1
                Tags:
                * feature_1
                * Release_2_0
                * 42_tag
                """, contains(item()
                .id("req", "bulleted-tags", 1)
                .addTag("feature_1")
                .addTag("Release_2_0")
                .addTag("42_tag")
                .location("tags_list.md", 1)
                .build()));
    }

    // [utest->dsn~md.tags-format~1]
    @Test
    void testBulletedTagsMalformedMixedList()
    {
        assertImport("tags_mixed.md", """
                req~mixed-tags~1
                Tags:
                * valid_1
                * _invalid
                * valid_2
                """, contains(item()
                .id("req", "mixed-tags", 1)
                .addTag("valid_1")
                .addTag("valid_2")
                .location("tags_mixed.md", 1)
                .build()));
    }

    // [utest->dsn~md.tags-format~1]
    @Test
    void testInlineAndBulletedTags()
    {
        assertImport("tags_inline_and_bulleted.md", """
                req~inline-and-bulleted-tags~1
                Tags: feature_1, feature_2
                * 1st_bullet
                + 2nd_bullet
                - 3rd_bullet
                """, contains(item()
                .id("req", "inline-and-bulleted-tags", 1)
                .addTag("feature_1")
                .addTag("feature_2")
                .addTag("1st_bullet")
                .addTag("2nd_bullet")
                .addTag("3rd_bullet")
                .location("tags_inline_and_bulleted.md", 1)
                .build()));
    }
}
