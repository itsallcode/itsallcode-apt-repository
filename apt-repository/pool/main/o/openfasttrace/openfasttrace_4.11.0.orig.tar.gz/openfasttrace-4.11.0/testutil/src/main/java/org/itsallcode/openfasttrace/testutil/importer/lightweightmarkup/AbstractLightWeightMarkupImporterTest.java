package org.itsallcode.openfasttrace.testutil.importer.lightweightmarkup;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.itsallcode.matcher.auto.AutoMatcher.contains;
import static org.itsallcode.openfasttrace.testutil.core.ItemBuilderFactory.item;

import java.nio.file.Path;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.hamcrest.Matcher;
import org.itsallcode.openfasttrace.api.core.*;
import org.itsallcode.openfasttrace.api.importer.ImporterFactory;
import org.itsallcode.openfasttrace.testutil.core.ItemBuilderFactory;
import org.itsallcode.openfasttrace.testutil.importer.ImportAssertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

/**
 * Base class for testing lightweight markup importers.
 */
public abstract class AbstractLightWeightMarkupImporterTest
{
    private static final String FILENAME = "the_file.md";
    private static final Path PATH = Path.of("/a/b/c.markdown");
    private static final String NL = System.lineSeparator();
    private static final Pattern TITLE_PLACEHOLDER = Pattern.compile("\\$\\{title\\(\"([^\"]+)\", (\\d+)\\)}");
    private final int titleLocationOffset;

    /**
     * Creates a new instance of the test base.
     * 
     * @param titleLocationOffset
     *            offset to add to line numbers when a title is present
     */
    protected AbstractLightWeightMarkupImporterTest(final int titleLocationOffset)
    {
        this.titleLocationOffset = titleLocationOffset;
    }

    /**
     * Format a title in the markup language.
     * 
     * @param title
     *            title text
     * @param level
     *            heading level
     * @return formatted title
     */
    protected abstract String formatTitle(final String title, int level);

    // [utest -> dsn~md.specification-item-id-format~3]
    @CsvSource({
            "at~name~67, at, name, 67",
            "longartifacttype~name.with.dots~123456789, longartifacttype, name.with.dots, 123456789",
            "a~b1.c1.d~0, a, b1.c1.d, 0"
    })
    @ParameterizedTest
    void testRequirementIdDetected(final String markdownId, final String expectedArtifactType,
            final String expectedName, final int expectedRevision)
    {
        assertImport(PATH, markdownId, contains(item()
                .id(expectedArtifactType, expectedName, expectedRevision)
                .location(PATH.toString(), 1)
                .build()));
    }

    /**
     * Assert that importing the given input produces specification items that match the given matcher.
     * 
     * @param path
     *            path to use for the input file
     * @param input
     *            input text to import
     * @param matcher
     *            matcher to verify the imported specification items
     */
    @SuppressWarnings("java:S4968") // Match type definition comes from Hamcrest. Cannot change.
    protected void assertImport(final String path, final String input,
            final Matcher<Iterable<? extends SpecificationItem>> matcher)
    {
        assertImport(Path.of(path), input, matcher);
    }

    /**
     * Assert that importing the given input produces specification items that match the given matcher.
     * 
     * @param path
     *            path to use for the input file
     * @param input
     *            input text to import
     * @param matcher
     *            matcher to verify the imported specification items
     */
    @SuppressWarnings("java:S4968") // Match type definition comes from Hamcrest. Cannot change.
    protected void assertImport(final Path path, final String input,
            final Matcher<Iterable<? extends SpecificationItem>> matcher)
    {
        final List<SpecificationItem> importedItems = ImportAssertions.runImporterOnText(path,
                processTextInput(input), getImporterFactory());
        assertThat(importedItems.stream().map(ItemBuilderFactory::withoutIdLocations)
                .toList(), matcher);
    }

    private String processTextInput(final String input)
    {
        return TITLE_PLACEHOLDER.matcher(input)
                .replaceAll(match -> formatTitle(match.group(1), Integer.parseInt(match.group(2))));
    }

    /**
     * Get the importer factory for testing.
     * 
     * @return importer factory
     */
    protected abstract ImporterFactory getImporterFactory();

    // [utest -> dsn~md.requirement-references~1]
    @Test
    void testSpecificationItemReferenceDetected()
    {
        assertImport(PATH, """
                `req~item-a~2`

                Covers:
                * `feat~item-b~1`
                """,
                contains(item()
                        .id("req", "item-a", 2)
                        .addCoveredId("feat", "item-b", 1)
                        .location(PATH.toString(), 1)
                        .build()));
    }

    @Test
    void testSpecificationItemReferenceWithDots()
    {
        assertImport(PATH, """
                `req~SR.AB.1.1.1~2`
                Covers:
                * `feat~SR.CD.1.2.3~4`
                """,
                contains(item()
                        .id("req", "SR.AB.1.1.1", 2)
                        .addCoveredId("feat", "SR.CD.1.2.3", 4)
                        .location(PATH.toString(), 1)
                        .build()));
    }

    // [utest -> dsn~md.covers-list~1]
    @Test
    void testSpecificationItemCoversList()
    {
        assertImport(PATH, """
                req~covers-list~4
                Covers:
                * `feat~item-A~1`
                * `feat~item-B~2`
                * `feat~item-C~3`
                """,
                contains(item()
                        .id("req", "covers-list", 4)
                        .addCoveredId("feat", "item-A", 1)
                        .addCoveredId("feat", "item-B", 2)
                        .addCoveredId("feat", "item-C", 3)
                        .location(PATH.toString(), 1)
                        .build()));
    }

    // [utest -> dsn~md.depends-list~1]
    @Test
    void testSpecificationItemDependsList()
    {
        assertImport(PATH, """
                req~depends-list~4
                Depends:
                * `feat~item-a~1`
                * `feat~item-b~2`
                * `feat~item-c~3`
                """,
                contains(item()
                        .id("req", "depends-list", 4)
                        .addDependOnId("feat", "item-a", 1)
                        .addDependOnId("feat", "item-b", 2)
                        .addDependOnId("feat", "item-c", 3)
                        .location(PATH.toString(), 1)
                        .build()));
    }

    // [utest -> dsn~md.needs-coverage-list-single-line~2]
    @Test
    void testSpecificationItemNeedsCoverageListCompact()
    {
        final Path path = Path.of("~/git/foo/bar.md");
        assertImport(path, """
                req~needs-coverage-list-single-line~4
                Needs: dsn, uman
                """,
                contains(item()
                        .id("req", "needs-coverage-list-single-line", 4)
                        .addNeedsArtifactType("dsn")
                        .addNeedsArtifactType("uman")
                        .location(path.toString(), 1)
                        .build()));
    }

    static Stream<Arguments> tags()
    {
        return Stream.of(
                Arguments.of("Tags: req , dsn ", List.of("req", "dsn")),
                Arguments.of("Tags: req ", List.of("req")),
                Arguments.of("Tags: req_1 ", List.of("req_1")),
                Arguments.of("Tags: req,dsn ", List.of("req", "dsn")),
                Arguments.of("Tags: req ,dsn", List.of("req", "dsn")),
                Arguments.of("Tags: req,dsn", List.of("req", "dsn")),
                Arguments.of("Tags: req,\tdsn\n", List.of("req", "dsn")),
                Arguments.of("Tags:req,dsn", List.of("req", "dsn")),
                Arguments.of("Tags: 1_req, 2", List.of("1_req", "2")),
                Arguments.of("Tags: a", List.of("a")),
                Arguments.of("Tags: 1", List.of("1")),
                Arguments.of("Tags:\n* req\n* dsn", List.of("req", "dsn")),
                Arguments.of("Tags:\n * req\n * dsn\n", List.of("req", "dsn")),
                Arguments.of("Tags:\n* req \n\t* dsn ", List.of("req", "dsn")),
                Arguments.of("Tags:\n* req\n* dsn", List.of("req", "dsn")),
                Arguments.of("Tags:\n* req_1\n* dsn_2", List.of("req_1", "dsn_2")),
                Arguments.of("Tags:\n* 1_req\n* 2", List.of("1_req", "2")),
                Arguments.of("Tags:\n* a\n* 1", List.of("a", "1")),
                Arguments.of("Tags:\n+ req\n+ dsn", List.of("req", "dsn")),
                Arguments.of("Tags:\n- req\n- dsn", List.of("req", "dsn")),

                // Regression test for #423:
                // In both declaration variants, individual invalid tags are rejected while valid tags are imported.
                Arguments.of("Tags: _ ", List.of()),
                Arguments.of("Tags: täg1, taeg2", List.of("taeg2")),
                Arguments.of("Tags: _tag1, taeg2", List.of("taeg2")),
                Arguments.of("Tags: tag1, -tag2", List.of("tag1")),
                Arguments.of("Tags: -dash, tag", List.of("tag")),
                Arguments.of("Tags: tag1, tag-2", List.of("tag1")),
                Arguments.of("Tags: tag1, tag#2", List.of("tag1")),
                Arguments.of("Tags: tag1, tag 2", List.of("tag1")),
                Arguments.of("Tags:\n* tag1\n* täg2", List.of("tag1")),
                Arguments.of("Tags:\n* -tag1\n* täg2", List.of()),
                Arguments.of("Tags:\n* _tag1\n* tag2", List.of("tag2")),
                Arguments.of("Tags:\n* tag1\n* _tag2", List.of("tag1")),
                Arguments.of("Tags:\n* tag1\n* -tag2", List.of("tag1")),
                Arguments.of("Tags:\n* _", List.of()),
                Arguments.of("Tags:\n* tag#1", List.of()),
                Arguments.of("Tags:\n* tag 1", List.of()));
    }

    // [utest -> dsn~md.tags-format~1]
    @ParameterizedTest
    @MethodSource("tags")
    void testTags(final String mdContent, final List<String> expected)
    {
        final List<SpecificationItem> items = ImportAssertions.runImporterOnText(Path.of("irrelevant-filename"),
                "`a~b~1`\n" + mdContent,
                getImporterFactory());
        assertThat(items.get(0).getTags(), equalTo(expected));
    }

    // [utest -> dsn~md.needs-coverage-list~1]
    @Test
    void testSpecificationItemNeedsCoverageList()
    {
        assertImport("needs-list.md", """
                req~needs-coverage-list~4
                Needs:
                * dsn
                * uman
                """,
                contains(item()
                        .id("req", "needs-coverage-list", 4)
                        .addNeedsArtifactType("dsn")
                        .addNeedsArtifactType("uman")
                        .location("needs-list.md", 1)
                        .build()));
    }

    // [utest -> dsn~md.artifact-forwarding-notation~1]
    @CsvSource({
            "dsn-->impl:req~foobar~1, dsn, impl, req, foobar, 1",
            " rsn-->sdk:req~foobar~2, rsn, sdk, req, foobar, 2",
            "dsn-->impl : test~foobar~3 , dsn, impl, test, foobar, 3",
            " rsn-->sdk : test~foobar~4 , rsn, sdk, test, foobar, 4",
            "dsn-->impl\t: req~foobar~1, dsn, impl, req, foobar, 1",
            "rsn-->sdk\t: \treq~foobar~2, rsn, sdk, req, foobar, 2",
            "dsn -->impl : test~foobar~3\t , dsn, impl, test, foobar, 3",
            "rsn -->sdk : test~foobar~4\t\t , rsn, sdk, test, foobar, 4"
    })
    @ParameterizedTest
    void testArtifactForwardingNotation(final String input, final String forwardedArtifactType,
            final String targetArtifactType, final String originalArtifactType,
            final String originalName, final int originalRevision)
    {
        assertImport("xyz", input,
                contains(item()
                        .id(forwardedArtifactType, originalName, originalRevision)
                        .addCoveredId(originalArtifactType, originalName, originalRevision)
                        .addNeedsArtifactType(targetArtifactType)
                        .forwards(true)
                        .location("xyz", 1)
                        .build()));
    }

    // [utest -> dsn~md.artifact-forwarding-notation~1]
    @Test
    void testForwardingAfterDepends()
    {
        assertImport(FILENAME, """
                dsn~foo~1
                Depends:
                * req~foo~1
                dsn-->impl:req~bar~2
                """,
                contains(
                        item()
                                .id("dsn", "foo", 1)
                                .location(FILENAME, 1)
                                .addDependOnId("req", "foo", 1)
                                .build(),
                        item()
                                .id("dsn", "bar", 2)
                                .addCoveredId("req", "bar", 2)
                                .addNeedsArtifactType("impl")
                                .location(FILENAME, 4)
                                .forwards(true)
                                .build()));
    }

    // [utest -> dsn~md.artifact-forwarding-notation~1]
    @Test
    void testForwardingAfterTags()
    {
        assertImport(FILENAME, """
                dsn~foo~1
                Tags: vanilla, strawberry, mint
                dsn-->impl:req~bar~2
                """,
                contains(
                        item()
                                .id("dsn", "foo", 1)
                                .location(FILENAME, 1)
                                .addTag("vanilla")
                                .addTag("strawberry")
                                .addTag("mint")
                                .build(),
                        item()
                                .id("dsn", "bar", 2)
                                .addCoveredId("req", "bar", 2)
                                .addNeedsArtifactType("impl")
                                .location(FILENAME, 3)
                                .forwards(true)
                                .build()));
    }

    // [utest -> dsn~md.artifact-forwarding-notation~1]
    @Test
    void testMultipleForwardsInARow()
    {
        assertImport(FILENAME, """
                ${title("A Collection of Different Forwards", 1)}
                * `arch --> dsn : req~foo~1`
                * arch  -->dsn  : req~bar~2   with a comment
                dsn-->impl      :    req~zoo~3
                """,
                contains(
                        item()
                                .id("arch", "foo", 1).addCoveredId("req", "foo", 1)
                                .addNeedsArtifactType("dsn")
                                .forwards(true)
                                .location(FILENAME, 2 + titleLocationOffset)
                                .build(),
                        item()
                                .id("arch", "bar", 2).addCoveredId("req", "bar", 2)
                                .addNeedsArtifactType("dsn")
                                .forwards(true)
                                .location(FILENAME, 3 + titleLocationOffset)
                                .build(),
                        item()
                                .id("dsn", "zoo", 3).addCoveredId("req", "zoo", 3)
                                .addNeedsArtifactType("impl")
                                .forwards(true)
                                .location(FILENAME, 4 + titleLocationOffset)
                                .build()));
    }

    // [utest -> dsn~md.artifact-forwarding-notation~1]
    @Test
    void testArtifactForwardingAfterARegularSpecificationItem()
    {
        assertImport("üöä", """
                art~name~9876

                ${title("Forwards", 1)}
                a-->b:c~d~5
                """,
                contains(
                        item()
                                .id("art", "name", 9876)
                                .location("üöä", 1)
                                .build(),
                        item()
                                .id("a", "d", 5)
                                .addCoveredId("c", "d", 5)
                                .addNeedsArtifactType("b")
                                .location("üöä", 4 + titleLocationOffset)
                                .forwards(true)
                                .build()));
    }

    // [utest -> dsn~md.artifact-forwarding-notation~1]
    @Test
    void testForwardingAfterCovers()
    {
        assertImport(FILENAME, """
                dsn~foo~1
                Covers:
                * req~foo~1
                dsn-->impl:req~bar~2
                """,
                contains(
                        item()
                                .id("dsn", "foo", 1)
                                .location(FILENAME, 1)
                                .addCoveredId("req", "foo", 1)
                                .build(),
                        item()
                                .id("dsn", "bar", 2)
                                .addCoveredId("req", "bar", 2)
                                .addNeedsArtifactType("impl")
                                .location(FILENAME, 4)
                                .forwards(true)
                                .build()));
    }

    // [utest -> dsn~md.artifact-forwarding-notation~1]
    @Test
    void testForwardingAfterNeeds()
    {
        assertImport(FILENAME, """
                dsn~foo~1
                Needs: impl
                dsn-->impl:req~bar~2
                """,
                contains(
                        item()
                                .id("dsn", "foo", 1)
                                .location(FILENAME, 1)
                                .addNeedsArtifactType("impl")
                                .build(),
                        item()
                                .id("dsn", "bar", 2)
                                .addCoveredId("req", "bar", 2)
                                .addNeedsArtifactType("impl")
                                .location(FILENAME, 3)
                                .forwards(true)
                                .build()));
    }

    @Test
    void testComplexRequirement()
    {
        assertImport("file name", """
                ${title("Requirement Title", 1)}
                `type~id~1` <a id="type~id~1"></a>
                Description

                More description

                Rationale:
                Rationale
                More rationale

                Covers:

                  * impl~foo1~1
                 + [Link to baz2](#impl~baz2~2)

                Depends:

                  + configuration~blubb.blah.blah~4711
                  - db~blah.blubb~42

                Comment:

                Comment
                More comment

                Needs: artA , artB
                """,
                contains(item().id(SpecificationItemId.parseId("type~id~1")).title("Requirement Title")
                        .comment("Comment" + NL + "More comment")
                        .description("Description" + NL + NL + "More description")
                        .rationale("Rationale" + NL + "More rationale")
                        .addNeedsArtifactType("artA").addNeedsArtifactType("artB")
                        .addCoveredId(SpecificationItemId.parseId("impl~foo1~1"))
                        .addCoveredId(SpecificationItemId.parseId("impl~baz2~2"))
                        .addDependOnId(SpecificationItemId
                                .parseId("configuration~blubb.blah.blah~4711"))
                        .addDependOnId(SpecificationItemId.parseId("db~blah.blubb~42"))
                        .location("file name", 2 + titleLocationOffset)
                        .build()));
    }

    @Test
    void testTwoConsecutiveSpecificationItems()
    {
        assertImport(FILENAME, """
                dsn~foo~1
                First description

                Comment:

                First comment

                dsn~bar~2
                Second description

                Rationale:
                Second rationale
                """,
                contains(
                        item()
                                .id("dsn", "foo", 1)
                                .description("First description")
                                .comment("First comment")
                                .location(FILENAME, 1)
                                .build(),
                        item()
                                .id("dsn", "bar", 2)
                                .description("Second description")
                                .rationale("Second rationale")
                                .location(FILENAME, 8)
                                .build()));
    }

    static Stream<Arguments> needsCoverage()
    {
        return Stream.of(
                Arguments.of("Needs: req , dsn ", List.of("req", "dsn")),
                Arguments.of("Needs: req ", List.of("req")),
                Arguments.of("Needs: req,dsn ", List.of("req", "dsn")),
                Arguments.of("Needs: req ,dsn", List.of("req", "dsn")),
                Arguments.of("Needs: req,dsn", List.of("req", "dsn")),
                Arguments.of("Needs: req,\tdsn\n", List.of("req", "dsn")),
                Arguments.of("Needs:req,dsn", List.of("req", "dsn")),
                Arguments.of("Needs:\n* req\n* dsn", List.of("req", "dsn")),
                Arguments.of("Needs:\n * req\n * dsn", List.of("req", "dsn")),
                Arguments.of("Needs:\n* req \n\t* dsn ", List.of("req", "dsn")),
                Arguments.of("Needs:\n* req\n* dsn", List.of("req", "dsn")));
    }

    @ParameterizedTest
    @MethodSource("needsCoverage")
    void testNeedsCoverage(final String mdContent, final List<String> expected)
    {
        final List<SpecificationItem> items = ImportAssertions.runImporterOnText(Path.of("irrelevant-filename"),
                "`a~b~1`\n" + mdContent,
                getImporterFactory());
        assertThat(items.get(0).getNeedsArtifactTypes(), equalTo(expected));
    }

    @Test
    void testItemStatsRecognized()
    {
        assertImport("status.MD", """
                `arch~status-enum~1`
                Status: draft
                """,
                contains(item()
                        .id("arch", "status-enum", 1)
                        .status(ItemStatus.DRAFT)
                        .location("status.MD", 1)
                        .build()));
    }

    // [impl -> dsn~md.specification-item-id-format~3] with UTF-8
    @Test
    void testItemIdSupportsUTF8Characaters()
    {
        assertImport("umlauts",
                """
                        ${title("Die Implementierung muss den Zustand einzelner Zellen ändern", 3)}
                        `req~zellzustandsänderung~1
                        Ermöglicht die Aktualisierung des Zustands von lebenden und toten Zellen in jeder Generation.
                        Needs: arch
                        """,
                contains(item()
                        .id(SpecificationItemId.createId("req", "zellzustandsänderung", 1))
                        .title("Die Implementierung muss den Zustand einzelner Zellen ändern")
                        .description("Ermöglicht die Aktualisierung des Zustands von lebenden und toten Zellen"
                                + " in jeder Generation.")
                        .location("umlauts", 2 + titleLocationOffset)
                        .addNeedsArtifactType("arch")
                        .build()));
    }

    @Test
    void testHeaderBelongsToNextItem()
    {
        assertImport("file", """
                ${title("Item 1", 1)}
                `req~item1~1
                Item 1 description

                ${title("Item 2", 1)}
                `req~item2~1
                Item 2 description
                """,
                contains(item().id(SpecificationItemId.createId("req", "item1", 1))
                        .title("Item 1")
                        .description("Item 1 description")
                        .location("file", 2 + titleLocationOffset)
                        .build(),
                        item().id(SpecificationItemId.createId("req", "item2", 1))
                                .title("Item 2")
                                .description("Item 2 description")
                                .location("file", 6 + (2 * titleLocationOffset))
                                .build()));
    }

    // This is a regression test for https://github.com/itsallcode/openfasttrace/issues/449
    @Test
    void testParsingNeedsIgnoresExtraListItems() {
        assertImport("needs_with_extra_list_items.md", """
                `feat~the-feature~1`

                Needs: arch

                * this must not be in needs section
                """,
                contains(item()
                        .id(SpecificationItemId.createId("feat", "the-feature", 1))
                        .addNeedsArtifactType("arch")
                        .description("* this must not be in needs section")
                        .location("needs_with_extra_list_items.md", 1)
                        .build()));
    }

    @Test
    void testNeedsAfterCovers() {
        assertImport("needs_after_covers.md", """
                `dsn~needs~3`

                Description with a bulleted list

                * this
                * that

                Covers:

                * `req~needs~2`

                Needs: itest
                """,
                contains(item()
                        .id(SpecificationItemId.createId("dsn", "needs", 3))
                        .description("Description with a bulleted list"
                                + System.lineSeparator()
                                + System.lineSeparator() + "* this"
                                + System.lineSeparator() + "* that")
                        .addCoveredId(SpecificationItemId.createId("req", "needs", 2))
                        .addNeedsArtifactType("itest")
                        .location("needs_after_covers.md", 1)
                        .build()));
    }
}
