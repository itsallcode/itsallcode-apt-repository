# OpenFastTrace 4.0.1, released 2024-06-22

Code name: Allow numbers after dots in specification item names

## Summary

This release allows using specification item names with dots `.` followed by numbers, e.g. `req~SR.AB.1.1.1~1`. We also updated the relevant [section in the user guide](../user_guide/introduction/concepts_and_terms.md#specification-item-name). Thanks to [@RobertZickler](https://github.com/RobertZickler) for reporting this!

## Bugfixes

* #417: Allow numbers after dots in specification item names (reported by [@RobertZickler](https://github.com/RobertZickler))
